# `tailscale_oauth_client`

Refer to the OpenTofu Registry for docs: [`tailscale_oauth_client`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/oauth_client).
