# `data_tailscale_device`

Refer to the OpenTofu Registry for docs: [`data_tailscale_device`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/device).
