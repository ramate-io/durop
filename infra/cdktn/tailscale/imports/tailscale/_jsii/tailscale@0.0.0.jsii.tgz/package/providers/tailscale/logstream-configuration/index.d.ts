import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface LogstreamConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The compression algorithm used for logs. Valid values are `none`, `zstd` or `gzip`. Defaults to `none`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#compression_format LogstreamConfiguration#compression_format}
    */
    readonly compressionFormat?: string;
    /**
    * The type of SIEM platform to stream to. Valid values are `axiom`, `cribl`, `datadog`, `elastic`, `gcs`, `panther`, `splunk`, and `s3`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#destination_type LogstreamConfiguration#destination_type}
    */
    readonly destinationType: string;
    /**
    * The name of the GCS bucket
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#gcs_bucket LogstreamConfiguration#gcs_bucket}
    */
    readonly gcsBucket?: string;
    /**
    * The encoded string of JSON that is used to authenticate for workload identity in GCS
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#gcs_credentials LogstreamConfiguration#gcs_credentials}
    */
    readonly gcsCredentials?: string;
    /**
    * The GCS key prefix for the bucket
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#gcs_key_prefix LogstreamConfiguration#gcs_key_prefix}
    */
    readonly gcsKeyPrefix?: string;
    /**
    * The GCS scopes needed to be able to write in the bucket
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#gcs_scopes LogstreamConfiguration#gcs_scopes}
    */
    readonly gcsScopes?: string[];
    /**
    * The type of logs to stream. Valid values are `configuration` (configuration audit logs) and `network` (network flow logs).
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#log_type LogstreamConfiguration#log_type}
    */
    readonly logType: string;
    /**
    * The S3 access key ID. Required if destination_type is s3 and s3_authentication_type is 'accesskey'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_access_key_id LogstreamConfiguration#s3_access_key_id}
    */
    readonly s3AccessKeyId?: string;
    /**
    * The type of authentication to use for S3. Required if destination_type is `s3`. Valid values are `accesskey` and `rolearn`. Tailscale recommends using `rolearn`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_authentication_type LogstreamConfiguration#s3_authentication_type}
    */
    readonly s3AuthenticationType?: string;
    /**
    * The S3 bucket name. Required if destination_type is 's3'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_bucket LogstreamConfiguration#s3_bucket}
    */
    readonly s3Bucket?: string;
    /**
    * The AWS External ID that Tailscale supplies when authenticating using role-based authentication. Required if destination_type is 's3' and s3_authentication_type is 'rolearn'. This can be obtained via the tailscale_aws_external_id resource.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_external_id LogstreamConfiguration#s3_external_id}
    */
    readonly s3ExternalId?: string;
    /**
    * An optional S3 key prefix to prepend to the auto-generated S3 key name.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_key_prefix LogstreamConfiguration#s3_key_prefix}
    */
    readonly s3KeyPrefix?: string;
    /**
    * The region in which the S3 bucket is located. Required if destination_type is 's3'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_region LogstreamConfiguration#s3_region}
    */
    readonly s3Region?: string;
    /**
    * ARN of the AWS IAM role that Tailscale should assume when using role-based authentication. Required if destination_type is 's3' and s3_authentication_type is 'rolearn'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_role_arn LogstreamConfiguration#s3_role_arn}
    */
    readonly s3RoleArn?: string;
    /**
    * The S3 secret access key. Required if destination_type is 's3' and s3_authentication_type is 'accesskey'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#s3_secret_access_key LogstreamConfiguration#s3_secret_access_key}
    */
    readonly s3SecretAccessKey?: string;
    /**
    * The token/password with which log streams to this endpoint should be authenticated, required unless destination_type is 's3'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#token LogstreamConfiguration#token}
    */
    readonly token?: string;
    /**
    * An optional number of minutes to wait in between uploading new logs. If the quantity of logs does not fit within a single upload, multiple uploads will be made.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#upload_period_minutes LogstreamConfiguration#upload_period_minutes}
    */
    readonly uploadPeriodMinutes?: number;
    /**
    * The URL to which log streams are being posted. If destination_type is 's3' and you want to use the official Amazon S3 endpoint, leave this empty.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#url LogstreamConfiguration#url}
    */
    readonly url?: string;
    /**
    * The username with which log streams to this endpoint are authenticated. Only required if destination_type is 'elastic', defaults to 'user' if not set.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#user LogstreamConfiguration#user}
    */
    readonly user?: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration tailscale_logstream_configuration}
*/
export declare class LogstreamConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_logstream_configuration";
    /**
    * Generates CDKTN code for importing a LogstreamConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the LogstreamConfiguration to import
    * @param importFromId The id of the existing LogstreamConfiguration that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the LogstreamConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration tailscale_logstream_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options LogstreamConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: LogstreamConfigurationConfig);
    private _compressionFormat?;
    get compressionFormat(): string;
    set compressionFormat(value: string);
    resetCompressionFormat(): void;
    get compressionFormatInput(): string | undefined;
    private _destinationType?;
    get destinationType(): string;
    set destinationType(value: string);
    get destinationTypeInput(): string | undefined;
    private _gcsBucket?;
    get gcsBucket(): string;
    set gcsBucket(value: string);
    resetGcsBucket(): void;
    get gcsBucketInput(): string | undefined;
    private _gcsCredentials?;
    get gcsCredentials(): string;
    set gcsCredentials(value: string);
    resetGcsCredentials(): void;
    get gcsCredentialsInput(): string | undefined;
    private _gcsKeyPrefix?;
    get gcsKeyPrefix(): string;
    set gcsKeyPrefix(value: string);
    resetGcsKeyPrefix(): void;
    get gcsKeyPrefixInput(): string | undefined;
    private _gcsScopes?;
    get gcsScopes(): string[];
    set gcsScopes(value: string[]);
    resetGcsScopes(): void;
    get gcsScopesInput(): string[] | undefined;
    get id(): string;
    private _logType?;
    get logType(): string;
    set logType(value: string);
    get logTypeInput(): string | undefined;
    private _s3AccessKeyId?;
    get s3AccessKeyId(): string;
    set s3AccessKeyId(value: string);
    resetS3AccessKeyId(): void;
    get s3AccessKeyIdInput(): string | undefined;
    private _s3AuthenticationType?;
    get s3AuthenticationType(): string;
    set s3AuthenticationType(value: string);
    resetS3AuthenticationType(): void;
    get s3AuthenticationTypeInput(): string | undefined;
    private _s3Bucket?;
    get s3Bucket(): string;
    set s3Bucket(value: string);
    resetS3Bucket(): void;
    get s3BucketInput(): string | undefined;
    private _s3ExternalId?;
    get s3ExternalId(): string;
    set s3ExternalId(value: string);
    resetS3ExternalId(): void;
    get s3ExternalIdInput(): string | undefined;
    private _s3KeyPrefix?;
    get s3KeyPrefix(): string;
    set s3KeyPrefix(value: string);
    resetS3KeyPrefix(): void;
    get s3KeyPrefixInput(): string | undefined;
    private _s3Region?;
    get s3Region(): string;
    set s3Region(value: string);
    resetS3Region(): void;
    get s3RegionInput(): string | undefined;
    private _s3RoleArn?;
    get s3RoleArn(): string;
    set s3RoleArn(value: string);
    resetS3RoleArn(): void;
    get s3RoleArnInput(): string | undefined;
    private _s3SecretAccessKey?;
    get s3SecretAccessKey(): string;
    set s3SecretAccessKey(value: string);
    resetS3SecretAccessKey(): void;
    get s3SecretAccessKeyInput(): string | undefined;
    private _token?;
    get token(): string;
    set token(value: string);
    resetToken(): void;
    get tokenInput(): string | undefined;
    private _uploadPeriodMinutes?;
    get uploadPeriodMinutes(): number;
    set uploadPeriodMinutes(value: number);
    resetUploadPeriodMinutes(): void;
    get uploadPeriodMinutesInput(): number | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    resetUrl(): void;
    get urlInput(): string | undefined;
    private _user?;
    get user(): string;
    set user(value: string);
    resetUser(): void;
    get userInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
