# `tailscale_logstream_configuration`

Refer to the OpenTofu Registry for docs: [`tailscale_logstream_configuration`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/logstream_configuration).
