# `tailscale_device_key`

Refer to the OpenTofu Registry for docs: [`tailscale_device_key`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_key).
