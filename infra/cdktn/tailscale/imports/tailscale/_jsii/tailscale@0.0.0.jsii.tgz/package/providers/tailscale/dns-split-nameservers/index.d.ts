import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsSplitNameserversConfig extends cdktn.TerraformMetaArguments {
    /**
    * Domain to configure split DNS for. Requests for this domain will be resolved using the provided nameservers. Changing this will force the resource to be recreated.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_split_nameservers#domain DnsSplitNameservers#domain}
    */
    readonly domain: string;
    /**
    * Devices on your network will use these nameservers to resolve DNS names. IPv4 or IPv6 addresses are accepted.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_split_nameservers#nameservers DnsSplitNameservers#nameservers}
    */
    readonly nameservers: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_split_nameservers tailscale_dns_split_nameservers}
*/
export declare class DnsSplitNameservers extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_dns_split_nameservers";
    /**
    * Generates CDKTN code for importing a DnsSplitNameservers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsSplitNameservers to import
    * @param importFromId The id of the existing DnsSplitNameservers that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_split_nameservers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsSplitNameservers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_split_nameservers tailscale_dns_split_nameservers} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsSplitNameserversConfig
    */
    constructor(scope: Construct, id: string, config: DnsSplitNameserversConfig);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    get id(): string;
    private _nameservers?;
    get nameservers(): string[];
    set nameservers(value: string[]);
    get nameserversInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
