import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TailnetKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the key consisting of alphanumeric characters. Defaults to `""`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#description TailnetKey#description}
    */
    readonly description?: string;
    /**
    * Indicates if the key is ephemeral. Defaults to `false`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#ephemeral TailnetKey#ephemeral}
    */
    readonly ephemeral?: boolean | cdktn.IResolvable;
    /**
    * The expiry of the key in seconds. Defaults to `7776000` (90 days).
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#expiry TailnetKey#expiry}
    */
    readonly expiry?: number;
    /**
    * Determines whether or not the machines authenticated by the key will be authorized for the tailnet by default. Defaults to `false`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#preauthorized TailnetKey#preauthorized}
    */
    readonly preauthorized?: boolean | cdktn.IResolvable;
    /**
    * Determines whether the key should be created again if it becomes invalid. By default, reusable keys will be recreated, but single-use keys will not. Possible values: 'always', 'never'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#recreate_if_invalid TailnetKey#recreate_if_invalid}
    */
    readonly recreateIfInvalid?: string;
    /**
    * Indicates if the key is reusable or single-use. Defaults to `false`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#reusable TailnetKey#reusable}
    */
    readonly reusable?: boolean | cdktn.IResolvable;
    /**
    * List of tags to apply to the machines authenticated by the key.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#tags TailnetKey#tags}
    */
    readonly tags?: string[];
    /**
    * ID of the user who created this key, empty for keys created by OAuth clients.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#user_id TailnetKey#user_id}
    */
    readonly userId?: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key tailscale_tailnet_key}
*/
export declare class TailnetKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_tailnet_key";
    /**
    * Generates CDKTN code for importing a TailnetKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TailnetKey to import
    * @param importFromId The id of the existing TailnetKey that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TailnetKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key tailscale_tailnet_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TailnetKeyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TailnetKeyConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _ephemeral?;
    get ephemeral(): boolean | cdktn.IResolvable;
    set ephemeral(value: boolean | cdktn.IResolvable);
    resetEphemeral(): void;
    get ephemeralInput(): boolean | cdktn.IResolvable | undefined;
    get expiresAt(): string;
    private _expiry?;
    get expiry(): number;
    set expiry(value: number);
    resetExpiry(): void;
    get expiryInput(): number | undefined;
    get id(): string;
    get invalid(): cdktn.IResolvable;
    get key(): string;
    private _preauthorized?;
    get preauthorized(): boolean | cdktn.IResolvable;
    set preauthorized(value: boolean | cdktn.IResolvable);
    resetPreauthorized(): void;
    get preauthorizedInput(): boolean | cdktn.IResolvable | undefined;
    private _recreateIfInvalid?;
    get recreateIfInvalid(): string;
    set recreateIfInvalid(value: string);
    resetRecreateIfInvalid(): void;
    get recreateIfInvalidInput(): string | undefined;
    private _reusable?;
    get reusable(): boolean | cdktn.IResolvable;
    set reusable(value: boolean | cdktn.IResolvable);
    resetReusable(): void;
    get reusableInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _userId?;
    get userId(): string;
    set userId(value: string);
    resetUserId(): void;
    get userIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
