# `tailscale_dns_split_nameservers`

Refer to the OpenTofu Registry for docs: [`tailscale_dns_split_nameservers`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_split_nameservers).
