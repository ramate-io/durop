# `data_tailscale_user`

Refer to the OpenTofu Registry for docs: [`data_tailscale_user`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/user).
