# `tailscale_device_subnet_routes`

Refer to the OpenTofu Registry for docs: [`tailscale_device_subnet_routes`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_subnet_routes).
