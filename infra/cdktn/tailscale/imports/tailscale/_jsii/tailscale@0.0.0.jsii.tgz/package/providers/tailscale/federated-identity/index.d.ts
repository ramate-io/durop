import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface FederatedIdentityConfig extends cdktn.TerraformMetaArguments {
    /**
    * The value used when matching against the `aud` claim from an OIDC identity token. Specifying the audience is optional as Tailscale will generate a secure audience at creation time by default.   It is recommended to let Tailscale generate the audience unless the identity provider you are integrating with requires a specific audience format.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#audience FederatedIdentity#audience}
    */
    readonly audience?: string;
    /**
    * A map of claim names to pattern strings used to match against arbitrary claims in the OIDC identity token. Patterns can include `*` characters to match against any character.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#custom_claim_rules FederatedIdentity#custom_claim_rules}
    */
    readonly customClaimRules?: {
        [key: string]: string;
    };
    /**
    * A description of the federated identity consisting of alphanumeric characters. Defaults to `""`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#description FederatedIdentity#description}
    */
    readonly description?: string;
    /**
    * The issuer of the OIDC identity token used in the token exchange. Must be a valid and publicly reachable https:// URL.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#issuer FederatedIdentity#issuer}
    */
    readonly issuer: string;
    /**
    * Scopes to grant to the federated identity. See https://tailscale.com/kb/1623/ for a list of available scopes.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#scopes FederatedIdentity#scopes}
    */
    readonly scopes: string[];
    /**
    * The pattern used when matching against the `sub` claim from an OIDC identity token. Patterns can include `*` characters to match against any character.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#subject FederatedIdentity#subject}
    */
    readonly subject: string;
    /**
    * A list of tags that access tokens generated for the federated identity will be able to assign to devices. Mandatory if the scopes include "devices:core" or "auth_keys".
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#tags FederatedIdentity#tags}
    */
    readonly tags?: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity tailscale_federated_identity}
*/
export declare class FederatedIdentity extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_federated_identity";
    /**
    * Generates CDKTN code for importing a FederatedIdentity resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the FederatedIdentity to import
    * @param importFromId The id of the existing FederatedIdentity that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the FederatedIdentity to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity tailscale_federated_identity} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options FederatedIdentityConfig
    */
    constructor(scope: Construct, id: string, config: FederatedIdentityConfig);
    private _audience?;
    get audience(): string;
    set audience(value: string);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    get createdAt(): string;
    private _customClaimRules?;
    get customClaimRules(): {
        [key: string]: string;
    };
    set customClaimRules(value: {
        [key: string]: string;
    });
    resetCustomClaimRules(): void;
    get customClaimRulesInput(): {
        [key: string]: string;
    } | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    private _issuer?;
    get issuer(): string;
    set issuer(value: string);
    get issuerInput(): string | undefined;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    private _subject?;
    get subject(): string;
    set subject(value: string);
    get subjectInput(): string | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    get userId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
