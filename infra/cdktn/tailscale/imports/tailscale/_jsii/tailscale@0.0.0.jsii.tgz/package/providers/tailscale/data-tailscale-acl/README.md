# `data_tailscale_acl`

Refer to the OpenTofu Registry for docs: [`data_tailscale_acl`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/acl).
