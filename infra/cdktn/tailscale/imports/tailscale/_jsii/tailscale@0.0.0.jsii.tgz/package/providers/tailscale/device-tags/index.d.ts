import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DeviceTagsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The device to set tags for
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_tags#device_id DeviceTags#device_id}
    */
    readonly deviceId: string;
    /**
    * The tags to apply to the device
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_tags#tags DeviceTags#tags}
    */
    readonly tags: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_tags tailscale_device_tags}
*/
export declare class DeviceTags extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_device_tags";
    /**
    * Generates CDKTN code for importing a DeviceTags resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeviceTags to import
    * @param importFromId The id of the existing DeviceTags that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_tags#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeviceTags to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_tags tailscale_device_tags} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeviceTagsConfig
    */
    constructor(scope: Construct, id: string, config: DeviceTagsConfig);
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    get deviceIdInput(): string | undefined;
    get id(): string;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    get tagsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
