# `provider`

Refer to the OpenTofu Registry for docs: [`tailscale`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs).
