# `tailscale_aws_external_id`

Refer to the OpenTofu Registry for docs: [`tailscale_aws_external_id`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/aws_external_id).
