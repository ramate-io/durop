import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DeviceAuthorizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether or not the device is authorized
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_authorization#authorized DeviceAuthorization#authorized}
    */
    readonly authorized: boolean | cdktn.IResolvable;
    /**
    * The device to set as authorized
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_authorization#device_id DeviceAuthorization#device_id}
    */
    readonly deviceId: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_authorization tailscale_device_authorization}
*/
export declare class DeviceAuthorization extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_device_authorization";
    /**
    * Generates CDKTN code for importing a DeviceAuthorization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeviceAuthorization to import
    * @param importFromId The id of the existing DeviceAuthorization that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_authorization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeviceAuthorization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_authorization tailscale_device_authorization} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeviceAuthorizationConfig
    */
    constructor(scope: Construct, id: string, config: DeviceAuthorizationConfig);
    private _authorized?;
    get authorized(): boolean | cdktn.IResolvable;
    set authorized(value: boolean | cdktn.IResolvable);
    get authorizedInput(): boolean | cdktn.IResolvable | undefined;
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    get deviceIdInput(): string | undefined;
    get id(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
