import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface WebhookConfig extends cdktn.TerraformMetaArguments {
    /**
    * The endpoint to send webhook events to.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/webhook#endpoint_url Webhook#endpoint_url}
    */
    readonly endpointUrl: string;
    /**
    * The provider type of the endpoint URL. This determines the payload format sent to the destination. Valid values are `slack`, `mattermost`, `googlechat`, and `discord`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/webhook#provider_type Webhook#provider_type}
    */
    readonly providerType?: string;
    /**
    * The set of events that trigger this webhook. For a full list of event types, see the [webhooks documentation](https://tailscale.com/kb/1213/webhooks#events).
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/webhook#subscriptions Webhook#subscriptions}
    */
    readonly subscriptions: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/webhook tailscale_webhook}
*/
export declare class Webhook extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_webhook";
    /**
    * Generates CDKTN code for importing a Webhook resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Webhook to import
    * @param importFromId The id of the existing Webhook that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/webhook#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Webhook to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/webhook tailscale_webhook} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options WebhookConfig
    */
    constructor(scope: Construct, id: string, config: WebhookConfig);
    private _endpointUrl?;
    get endpointUrl(): string;
    set endpointUrl(value: string);
    get endpointUrlInput(): string | undefined;
    get id(): string;
    private _providerType?;
    get providerType(): string;
    set providerType(value: string);
    resetProviderType(): void;
    get providerTypeInput(): string | undefined;
    get secret(): string;
    private _subscriptions?;
    get subscriptions(): string[];
    set subscriptions(value: string[]);
    get subscriptionsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
