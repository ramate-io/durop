"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.TailnetSettings = void 0;
const JSII_RTTI_SYMBOL_1 = Symbol.for("jsii.rtti");
const cdktn = __importStar(require("cdktn"));
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings tailscale_tailnet_settings}
*/
class TailnetSettings extends cdktn.TerraformResource {
    static [JSII_RTTI_SYMBOL_1] = { fqn: "tailscale.tailnetSettings.TailnetSettings", version: "0.0.0" };
    // =================
    // STATIC PROPERTIES
    // =================
    static tfResourceType = "tailscale_tailnet_settings";
    // ==============
    // STATIC Methods
    // ==============
    /**
    * Generates CDKTN code for importing a TailnetSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TailnetSettings to import
    * @param importFromId The id of the existing TailnetSettings that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TailnetSettings to import is found
    */
    static generateConfigForImport(scope, importToId, importFromId, provider) {
        return new cdktn.ImportableResource(scope, importToId, { terraformResourceType: "tailscale_tailnet_settings", importId: importFromId, provider });
    }
    // ===========
    // INITIALIZER
    // ===========
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings tailscale_tailnet_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TailnetSettingsConfig = {}
    */
    constructor(scope, id, config = {}) {
        super(scope, id, {
            terraformResourceType: 'tailscale_tailnet_settings',
            terraformGeneratorMetadata: {
                providerName: 'tailscale',
                providerVersion: '0.29.2',
                providerVersionConstraint: '=0.29.2'
            },
            provider: config.provider,
            dependsOn: config.dependsOn,
            count: config.count,
            lifecycle: config.lifecycle,
            provisioners: config.provisioners,
            connection: config.connection,
            forEach: config.forEach
        });
        this._aclsExternalLink = config.aclsExternalLink;
        this._aclsExternallyManagedOn = config.aclsExternallyManagedOn;
        this._devicesApprovalOn = config.devicesApprovalOn;
        this._devicesAutoUpdatesOn = config.devicesAutoUpdatesOn;
        this._devicesKeyDurationDays = config.devicesKeyDurationDays;
        this._httpsEnabled = config.httpsEnabled;
        this._networkFlowLoggingOn = config.networkFlowLoggingOn;
        this._postureIdentityCollectionOn = config.postureIdentityCollectionOn;
        this._regionalRoutingOn = config.regionalRoutingOn;
        this._usersApprovalOn = config.usersApprovalOn;
        this._usersRoleAllowedToJoinExternalTailnet = config.usersRoleAllowedToJoinExternalTailnet;
    }
    // ==========
    // ATTRIBUTES
    // ==========
    // acls_external_link - computed: true, optional: true, required: false
    _aclsExternalLink;
    get aclsExternalLink() {
        return this.getStringAttribute('acls_external_link');
    }
    set aclsExternalLink(value) {
        this._aclsExternalLink = value;
    }
    resetAclsExternalLink() {
        this._aclsExternalLink = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get aclsExternalLinkInput() {
        return this._aclsExternalLink;
    }
    // acls_externally_managed_on - computed: true, optional: true, required: false
    _aclsExternallyManagedOn;
    get aclsExternallyManagedOn() {
        return this.getBooleanAttribute('acls_externally_managed_on');
    }
    set aclsExternallyManagedOn(value) {
        this._aclsExternallyManagedOn = value;
    }
    resetAclsExternallyManagedOn() {
        this._aclsExternallyManagedOn = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get aclsExternallyManagedOnInput() {
        return this._aclsExternallyManagedOn;
    }
    // devices_approval_on - computed: true, optional: true, required: false
    _devicesApprovalOn;
    get devicesApprovalOn() {
        return this.getBooleanAttribute('devices_approval_on');
    }
    set devicesApprovalOn(value) {
        this._devicesApprovalOn = value;
    }
    resetDevicesApprovalOn() {
        this._devicesApprovalOn = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get devicesApprovalOnInput() {
        return this._devicesApprovalOn;
    }
    // devices_auto_updates_on - computed: true, optional: true, required: false
    _devicesAutoUpdatesOn;
    get devicesAutoUpdatesOn() {
        return this.getBooleanAttribute('devices_auto_updates_on');
    }
    set devicesAutoUpdatesOn(value) {
        this._devicesAutoUpdatesOn = value;
    }
    resetDevicesAutoUpdatesOn() {
        this._devicesAutoUpdatesOn = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get devicesAutoUpdatesOnInput() {
        return this._devicesAutoUpdatesOn;
    }
    // devices_key_duration_days - computed: true, optional: true, required: false
    _devicesKeyDurationDays;
    get devicesKeyDurationDays() {
        return this.getNumberAttribute('devices_key_duration_days');
    }
    set devicesKeyDurationDays(value) {
        this._devicesKeyDurationDays = value;
    }
    resetDevicesKeyDurationDays() {
        this._devicesKeyDurationDays = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get devicesKeyDurationDaysInput() {
        return this._devicesKeyDurationDays;
    }
    // https_enabled - computed: true, optional: true, required: false
    _httpsEnabled;
    get httpsEnabled() {
        return this.getBooleanAttribute('https_enabled');
    }
    set httpsEnabled(value) {
        this._httpsEnabled = value;
    }
    resetHttpsEnabled() {
        this._httpsEnabled = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get httpsEnabledInput() {
        return this._httpsEnabled;
    }
    // id - computed: true, optional: false, required: false
    get id() {
        return this.getStringAttribute('id');
    }
    // network_flow_logging_on - computed: true, optional: true, required: false
    _networkFlowLoggingOn;
    get networkFlowLoggingOn() {
        return this.getBooleanAttribute('network_flow_logging_on');
    }
    set networkFlowLoggingOn(value) {
        this._networkFlowLoggingOn = value;
    }
    resetNetworkFlowLoggingOn() {
        this._networkFlowLoggingOn = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get networkFlowLoggingOnInput() {
        return this._networkFlowLoggingOn;
    }
    // posture_identity_collection_on - computed: true, optional: true, required: false
    _postureIdentityCollectionOn;
    get postureIdentityCollectionOn() {
        return this.getBooleanAttribute('posture_identity_collection_on');
    }
    set postureIdentityCollectionOn(value) {
        this._postureIdentityCollectionOn = value;
    }
    resetPostureIdentityCollectionOn() {
        this._postureIdentityCollectionOn = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get postureIdentityCollectionOnInput() {
        return this._postureIdentityCollectionOn;
    }
    // regional_routing_on - computed: true, optional: true, required: false
    _regionalRoutingOn;
    get regionalRoutingOn() {
        return this.getBooleanAttribute('regional_routing_on');
    }
    set regionalRoutingOn(value) {
        this._regionalRoutingOn = value;
    }
    resetRegionalRoutingOn() {
        this._regionalRoutingOn = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get regionalRoutingOnInput() {
        return this._regionalRoutingOn;
    }
    // users_approval_on - computed: true, optional: true, required: false
    _usersApprovalOn;
    get usersApprovalOn() {
        return this.getBooleanAttribute('users_approval_on');
    }
    set usersApprovalOn(value) {
        this._usersApprovalOn = value;
    }
    resetUsersApprovalOn() {
        this._usersApprovalOn = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get usersApprovalOnInput() {
        return this._usersApprovalOn;
    }
    // users_role_allowed_to_join_external_tailnet - computed: true, optional: true, required: false
    _usersRoleAllowedToJoinExternalTailnet;
    get usersRoleAllowedToJoinExternalTailnet() {
        return this.getStringAttribute('users_role_allowed_to_join_external_tailnet');
    }
    set usersRoleAllowedToJoinExternalTailnet(value) {
        this._usersRoleAllowedToJoinExternalTailnet = value;
    }
    resetUsersRoleAllowedToJoinExternalTailnet() {
        this._usersRoleAllowedToJoinExternalTailnet = undefined;
    }
    // Temporarily expose input value. Use with caution.
    get usersRoleAllowedToJoinExternalTailnetInput() {
        return this._usersRoleAllowedToJoinExternalTailnet;
    }
    // =========
    // SYNTHESIS
    // =========
    synthesizeAttributes() {
        return {
            acls_external_link: cdktn.stringToTerraform(this._aclsExternalLink),
            acls_externally_managed_on: cdktn.booleanToTerraform(this._aclsExternallyManagedOn),
            devices_approval_on: cdktn.booleanToTerraform(this._devicesApprovalOn),
            devices_auto_updates_on: cdktn.booleanToTerraform(this._devicesAutoUpdatesOn),
            devices_key_duration_days: cdktn.numberToTerraform(this._devicesKeyDurationDays),
            https_enabled: cdktn.booleanToTerraform(this._httpsEnabled),
            network_flow_logging_on: cdktn.booleanToTerraform(this._networkFlowLoggingOn),
            posture_identity_collection_on: cdktn.booleanToTerraform(this._postureIdentityCollectionOn),
            regional_routing_on: cdktn.booleanToTerraform(this._regionalRoutingOn),
            users_approval_on: cdktn.booleanToTerraform(this._usersApprovalOn),
            users_role_allowed_to_join_external_tailnet: cdktn.stringToTerraform(this._usersRoleAllowedToJoinExternalTailnet),
        };
    }
    synthesizeHclAttributes() {
        const attrs = {
            acls_external_link: {
                value: cdktn.stringToHclTerraform(this._aclsExternalLink),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
            acls_externally_managed_on: {
                value: cdktn.booleanToHclTerraform(this._aclsExternallyManagedOn),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            devices_approval_on: {
                value: cdktn.booleanToHclTerraform(this._devicesApprovalOn),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            devices_auto_updates_on: {
                value: cdktn.booleanToHclTerraform(this._devicesAutoUpdatesOn),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            devices_key_duration_days: {
                value: cdktn.numberToHclTerraform(this._devicesKeyDurationDays),
                isBlock: false,
                type: "simple",
                storageClassType: "number",
            },
            https_enabled: {
                value: cdktn.booleanToHclTerraform(this._httpsEnabled),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            network_flow_logging_on: {
                value: cdktn.booleanToHclTerraform(this._networkFlowLoggingOn),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            posture_identity_collection_on: {
                value: cdktn.booleanToHclTerraform(this._postureIdentityCollectionOn),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            regional_routing_on: {
                value: cdktn.booleanToHclTerraform(this._regionalRoutingOn),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            users_approval_on: {
                value: cdktn.booleanToHclTerraform(this._usersApprovalOn),
                isBlock: false,
                type: "simple",
                storageClassType: "boolean",
            },
            users_role_allowed_to_join_external_tailnet: {
                value: cdktn.stringToHclTerraform(this._usersRoleAllowedToJoinExternalTailnet),
                isBlock: false,
                type: "simple",
                storageClassType: "string",
            },
        };
        // remove undefined attributes
        return Object.fromEntries(Object.entries(attrs).filter(([_, value]) => value !== undefined && value.value !== undefined));
    }
}
exports.TailnetSettings = TailnetSettings;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSUEsNkNBQStCO0FBeUUvQjs7RUFFRTtBQUNGLE1BQWEsZUFBZ0IsU0FBUSxLQUFLLENBQUMsaUJBQWlCOztJQUUxRCxvQkFBb0I7SUFDcEIsb0JBQW9CO0lBQ3BCLG9CQUFvQjtJQUNiLE1BQU0sQ0FBVSxjQUFjLEdBQUcsNEJBQTRCLENBQUM7SUFFckUsaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7SUFDakI7Ozs7OztNQU1FO0lBQ0ssTUFBTSxDQUFDLHVCQUF1QixDQUFDLEtBQWdCLEVBQUUsVUFBa0IsRUFBRSxZQUFvQixFQUFFLFFBQWtDO1FBQzlILE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLENBQUMsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFLHFCQUFxQixFQUFFLDRCQUE0QixFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUNwSixDQUFDO0lBRUwsY0FBYztJQUNkLGNBQWM7SUFDZCxjQUFjO0lBRWQ7Ozs7OztNQU1FO0lBQ0YsWUFBbUIsS0FBZ0IsRUFBRSxFQUFVLEVBQUUsU0FBZ0MsRUFBRTtRQUNqRixLQUFLLENBQUMsS0FBSyxFQUFFLEVBQUUsRUFBRTtZQUNmLHFCQUFxQixFQUFFLDRCQUE0QjtZQUNuRCwwQkFBMEIsRUFBRTtnQkFDMUIsWUFBWSxFQUFFLFdBQVc7Z0JBQ3pCLGVBQWUsRUFBRSxRQUFRO2dCQUN6Qix5QkFBeUIsRUFBRSxTQUFTO2FBQ3JDO1lBQ0QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO1lBQ3pCLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7WUFDbkIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO1lBQzNCLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtZQUNqQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7WUFDN0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1NBQ3hCLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxpQkFBaUIsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUM7UUFDakQsSUFBSSxDQUFDLHdCQUF3QixHQUFHLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztRQUMvRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBQ25ELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUM7UUFDekQsSUFBSSxDQUFDLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQztRQUM3RCxJQUFJLENBQUMsYUFBYSxHQUFHLE1BQU0sQ0FBQyxZQUFZLENBQUM7UUFDekMsSUFBSSxDQUFDLHFCQUFxQixHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQztRQUN6RCxJQUFJLENBQUMsNEJBQTRCLEdBQUcsTUFBTSxDQUFDLDJCQUEyQixDQUFDO1FBQ3ZFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUM7UUFDbkQsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU0sQ0FBQyxlQUFlLENBQUM7UUFDL0MsSUFBSSxDQUFDLHNDQUFzQyxHQUFHLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQztJQUM3RixDQUFDO0lBRUQsYUFBYTtJQUNiLGFBQWE7SUFDYixhQUFhO0lBRWIsdUVBQXVFO0lBQy9ELGlCQUFpQixDQUFVO0lBQ25DLElBQVcsZ0JBQWdCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUNELElBQVcsZ0JBQWdCLENBQUMsS0FBYTtRQUN2QyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBQ2pDLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQztJQUNyQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcscUJBQXFCO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGlCQUFpQixDQUFDO0lBQ2hDLENBQUM7SUFFRCwrRUFBK0U7SUFDdkUsd0JBQXdCLENBQStCO0lBQy9ELElBQVcsdUJBQXVCO1FBQ2hDLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLDRCQUE0QixDQUFDLENBQUM7SUFDaEUsQ0FBQztJQUNELElBQVcsdUJBQXVCLENBQUMsS0FBa0M7UUFDbkUsSUFBSSxDQUFDLHdCQUF3QixHQUFHLEtBQUssQ0FBQztJQUN4QyxDQUFDO0lBQ00sNEJBQTRCO1FBQ2pDLElBQUksQ0FBQyx3QkFBd0IsR0FBRyxTQUFTLENBQUM7SUFDNUMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLDRCQUE0QjtRQUNyQyxPQUFPLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztJQUN2QyxDQUFDO0lBRUQsd0VBQXdFO0lBQ2hFLGtCQUFrQixDQUErQjtJQUN6RCxJQUFXLGlCQUFpQjtRQUMxQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFDRCxJQUFXLGlCQUFpQixDQUFDLEtBQWtDO1FBQzdELElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDbEMsQ0FBQztJQUNNLHNCQUFzQjtRQUMzQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO0lBQ3RDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUM7SUFDakMsQ0FBQztJQUVELDRFQUE0RTtJQUNwRSxxQkFBcUIsQ0FBK0I7SUFDNUQsSUFBVyxvQkFBb0I7UUFDN0IsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMseUJBQXlCLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBQ0QsSUFBVyxvQkFBb0IsQ0FBQyxLQUFrQztRQUNoRSxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxDQUFDO0lBQ3JDLENBQUM7SUFDTSx5QkFBeUI7UUFDOUIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLFNBQVMsQ0FBQztJQUN6QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcseUJBQXlCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLHFCQUFxQixDQUFDO0lBQ3BDLENBQUM7SUFFRCw4RUFBOEU7SUFDdEUsdUJBQXVCLENBQVU7SUFDekMsSUFBVyxzQkFBc0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsMkJBQTJCLENBQUMsQ0FBQztJQUM5RCxDQUFDO0lBQ0QsSUFBVyxzQkFBc0IsQ0FBQyxLQUFhO1FBQzdDLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxLQUFLLENBQUM7SUFDdkMsQ0FBQztJQUNNLDJCQUEyQjtRQUNoQyxJQUFJLENBQUMsdUJBQXVCLEdBQUcsU0FBUyxDQUFDO0lBQzNDLENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywyQkFBMkI7UUFDcEMsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQUM7SUFDdEMsQ0FBQztJQUVELGtFQUFrRTtJQUMxRCxhQUFhLENBQStCO0lBQ3BELElBQVcsWUFBWTtRQUNyQixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsQ0FBQztJQUNuRCxDQUFDO0lBQ0QsSUFBVyxZQUFZLENBQUMsS0FBa0M7UUFDeEQsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFDN0IsQ0FBQztJQUNNLGlCQUFpQjtRQUN0QixJQUFJLENBQUMsYUFBYSxHQUFHLFNBQVMsQ0FBQztJQUNqQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsaUJBQWlCO1FBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztJQUM1QixDQUFDO0lBRUQsd0RBQXdEO0lBQ3hELElBQVcsRUFBRTtRQUNYLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCw0RUFBNEU7SUFDcEUscUJBQXFCLENBQStCO0lBQzVELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLG1CQUFtQixDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUNELElBQVcsb0JBQW9CLENBQUMsS0FBa0M7UUFDaEUsSUFBSSxDQUFDLHFCQUFxQixHQUFHLEtBQUssQ0FBQztJQUNyQyxDQUFDO0lBQ00seUJBQXlCO1FBQzlCLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxTQUFTLENBQUM7SUFDekMsQ0FBQztJQUNELG9EQUFvRDtJQUNwRCxJQUFXLHlCQUF5QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztJQUNwQyxDQUFDO0lBRUQsbUZBQW1GO0lBQzNFLDRCQUE0QixDQUErQjtJQUNuRSxJQUFXLDJCQUEyQjtRQUNwQyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0lBQ3BFLENBQUM7SUFDRCxJQUFXLDJCQUEyQixDQUFDLEtBQWtDO1FBQ3ZFLElBQUksQ0FBQyw0QkFBNEIsR0FBRyxLQUFLLENBQUM7SUFDNUMsQ0FBQztJQUNNLGdDQUFnQztRQUNyQyxJQUFJLENBQUMsNEJBQTRCLEdBQUcsU0FBUyxDQUFDO0lBQ2hELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVyxnQ0FBZ0M7UUFDekMsT0FBTyxJQUFJLENBQUMsNEJBQTRCLENBQUM7SUFDM0MsQ0FBQztJQUVELHdFQUF3RTtJQUNoRSxrQkFBa0IsQ0FBK0I7SUFDekQsSUFBVyxpQkFBaUI7UUFDMUIsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBQ0QsSUFBVyxpQkFBaUIsQ0FBQyxLQUFrQztRQUM3RCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO0lBQ2xDLENBQUM7SUFDTSxzQkFBc0I7UUFDM0IsSUFBSSxDQUFDLGtCQUFrQixHQUFHLFNBQVMsQ0FBQztJQUN0QyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsc0JBQXNCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDO0lBQ2pDLENBQUM7SUFFRCxzRUFBc0U7SUFDOUQsZ0JBQWdCLENBQStCO0lBQ3ZELElBQVcsZUFBZTtRQUN4QixPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFDRCxJQUFXLGVBQWUsQ0FBQyxLQUFrQztRQUMzRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBQ2hDLENBQUM7SUFDTSxvQkFBb0I7UUFDekIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFNBQVMsQ0FBQztJQUNwQyxDQUFDO0lBQ0Qsb0RBQW9EO0lBQ3BELElBQVcsb0JBQW9CO1FBQzdCLE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQy9CLENBQUM7SUFFRCxnR0FBZ0c7SUFDeEYsc0NBQXNDLENBQVU7SUFDeEQsSUFBVyxxQ0FBcUM7UUFDOUMsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsNkNBQTZDLENBQUMsQ0FBQztJQUNoRixDQUFDO0lBQ0QsSUFBVyxxQ0FBcUMsQ0FBQyxLQUFhO1FBQzVELElBQUksQ0FBQyxzQ0FBc0MsR0FBRyxLQUFLLENBQUM7SUFDdEQsQ0FBQztJQUNNLDBDQUEwQztRQUMvQyxJQUFJLENBQUMsc0NBQXNDLEdBQUcsU0FBUyxDQUFDO0lBQzFELENBQUM7SUFDRCxvREFBb0Q7SUFDcEQsSUFBVywwQ0FBMEM7UUFDbkQsT0FBTyxJQUFJLENBQUMsc0NBQXNDLENBQUM7SUFDckQsQ0FBQztJQUVELFlBQVk7SUFDWixZQUFZO0lBQ1osWUFBWTtJQUVGLG9CQUFvQjtRQUM1QixPQUFPO1lBQ0wsa0JBQWtCLEVBQUUsS0FBSyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQztZQUNuRSwwQkFBMEIsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDO1lBQ25GLG1CQUFtQixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7WUFDdEUsdUJBQXVCLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztZQUM3RSx5QkFBeUIsRUFBRSxLQUFLLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDO1lBQ2hGLGFBQWEsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUMzRCx1QkFBdUIsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO1lBQzdFLDhCQUE4QixFQUFFLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsNEJBQTRCLENBQUM7WUFDM0YsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztZQUN0RSxpQkFBaUIsRUFBRSxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1lBQ2xFLDJDQUEyQyxFQUFFLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsc0NBQXNDLENBQUM7U0FDbEgsQ0FBQztJQUNKLENBQUM7SUFFUyx1QkFBdUI7UUFDL0IsTUFBTSxLQUFLLEdBQUc7WUFDWixrQkFBa0IsRUFBRTtnQkFDbEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUM7Z0JBQ3pELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCwwQkFBMEIsRUFBRTtnQkFDMUIsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsd0JBQXdCLENBQUM7Z0JBQ2pFLE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFNBQVM7YUFDNUI7WUFDRCxtQkFBbUIsRUFBRTtnQkFDbkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUM7Z0JBQzNELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFNBQVM7YUFDNUI7WUFDRCx1QkFBdUIsRUFBRTtnQkFDdkIsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUM7Z0JBQzlELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFNBQVM7YUFDNUI7WUFDRCx5QkFBeUIsRUFBRTtnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUM7Z0JBQy9ELE9BQU8sRUFBRSxLQUFLO2dCQUNkLElBQUksRUFBRSxRQUFRO2dCQUNkLGdCQUFnQixFQUFFLFFBQVE7YUFDM0I7WUFDRCxhQUFhLEVBQUU7Z0JBQ2IsS0FBSyxFQUFFLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUN0RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsdUJBQXVCLEVBQUU7Z0JBQ3ZCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO2dCQUM5RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsOEJBQThCLEVBQUU7Z0JBQzlCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLDRCQUE0QixDQUFDO2dCQUNyRSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUMzRCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsaUJBQWlCLEVBQUU7Z0JBQ2pCLEtBQUssRUFBRSxLQUFLLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO2dCQUN6RCxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxTQUFTO2FBQzVCO1lBQ0QsMkNBQTJDLEVBQUU7Z0JBQzNDLEtBQUssRUFBRSxLQUFLLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLHNDQUFzQyxDQUFDO2dCQUM5RSxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsUUFBUTtnQkFDZCxnQkFBZ0IsRUFBRSxRQUFRO2FBQzNCO1NBQ0YsQ0FBQztRQUVGLDhCQUE4QjtRQUM5QixPQUFPLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLENBQUMsS0FBSyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsS0FBSyxLQUFLLFNBQVMsQ0FBRSxDQUFDLENBQUE7SUFDNUgsQ0FBQzs7QUFsVkgsMENBbVZDIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaHR0cHM6Ly9zZWFyY2gub3BlbnRvZnUub3JnL3Byb3ZpZGVyL3RhaWxzY2FsZS90YWlsc2NhbGUvdjAuMjkuMi9kb2NzL3Jlc291cmNlcy90YWlsbmV0X3NldHRpbmdzXG4vLyBnZW5lcmF0ZWQgZnJvbSB0ZXJyYWZvcm0gcmVzb3VyY2Ugc2NoZW1hXG5cbmltcG9ydCB7IENvbnN0cnVjdCB9IGZyb20gJ2NvbnN0cnVjdHMnO1xuaW1wb3J0ICogYXMgY2RrdG4gZnJvbSAnY2RrdG4nO1xuXG4vLyBDb25maWd1cmF0aW9uXG5cbmV4cG9ydCBpbnRlcmZhY2UgVGFpbG5ldFNldHRpbmdzQ29uZmlnIGV4dGVuZHMgY2RrdG4uVGVycmFmb3JtTWV0YUFyZ3VtZW50cyB7XG4gIC8qKlxuICAqIExpbmsgdG8geW91ciBleHRlcm5hbCBBQ0wgZGVmaW5pdGlvbiBvciBtYW5hZ2VtZW50IHN5c3RlbS4gTXVzdCBiZSBhIHZhbGlkIFVSTC5cbiAgKlxuICAqIERvY3MgYXQgT3BlblRvZnUgUmVnaXN0cnk6IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MjYWNsc19leHRlcm5hbF9saW5rIFRhaWxuZXRTZXR0aW5ncyNhY2xzX2V4dGVybmFsX2xpbmt9XG4gICovXG4gIHJlYWRvbmx5IGFjbHNFeHRlcm5hbExpbms/OiBzdHJpbmc7XG4gIC8qKlxuICAqIFByZXZlbnQgdXNlcnMgZnJvbSBlZGl0aW5nIHBvbGljaWVzIGluIHRoZSBhZG1pbiBjb25zb2xlIHRvIGF2b2lkIGNvbmZsaWN0cyB3aXRoIGV4dGVybmFsIG1hbmFnZW1lbnQgd29ya2Zsb3dzIGxpa2UgR2l0T3BzIG9yIFRlcnJhZm9ybS5cbiAgKlxuICAqIERvY3MgYXQgT3BlblRvZnUgUmVnaXN0cnk6IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MjYWNsc19leHRlcm5hbGx5X21hbmFnZWRfb24gVGFpbG5ldFNldHRpbmdzI2FjbHNfZXh0ZXJuYWxseV9tYW5hZ2VkX29ufVxuICAqL1xuICByZWFkb25seSBhY2xzRXh0ZXJuYWxseU1hbmFnZWRPbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogV2hldGhlciBkZXZpY2UgYXBwcm92YWwgaXMgZW5hYmxlZCBmb3IgdGhlIHRhaWxuZXRcbiAgKlxuICAqIERvY3MgYXQgT3BlblRvZnUgUmVnaXN0cnk6IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MjZGV2aWNlc19hcHByb3ZhbF9vbiBUYWlsbmV0U2V0dGluZ3MjZGV2aWNlc19hcHByb3ZhbF9vbn1cbiAgKi9cbiAgcmVhZG9ubHkgZGV2aWNlc0FwcHJvdmFsT24/OiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGU7XG4gIC8qKlxuICAqIFdoZXRoZXIgYXV0byB1cGRhdGVzIGFyZSBlbmFibGVkIGZvciBkZXZpY2VzIHRoYXQgYmVsb25nIHRvIHRoaXMgdGFpbG5ldFxuICAqXG4gICogRG9jcyBhdCBPcGVuVG9mdSBSZWdpc3RyeToge0BsaW5rIGh0dHBzOi8vc2VhcmNoLm9wZW50b2Z1Lm9yZy9wcm92aWRlci90YWlsc2NhbGUvdGFpbHNjYWxlL3YwLjI5LjIvZG9jcy9yZXNvdXJjZXMvdGFpbG5ldF9zZXR0aW5ncyNkZXZpY2VzX2F1dG9fdXBkYXRlc19vbiBUYWlsbmV0U2V0dGluZ3MjZGV2aWNlc19hdXRvX3VwZGF0ZXNfb259XG4gICovXG4gIHJlYWRvbmx5IGRldmljZXNBdXRvVXBkYXRlc09uPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBUaGUga2V5IGV4cGlyeSBkdXJhdGlvbiBmb3IgZGV2aWNlcyBvbiB0aGlzIHRhaWxuZXRcbiAgKlxuICAqIERvY3MgYXQgT3BlblRvZnUgUmVnaXN0cnk6IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MjZGV2aWNlc19rZXlfZHVyYXRpb25fZGF5cyBUYWlsbmV0U2V0dGluZ3MjZGV2aWNlc19rZXlfZHVyYXRpb25fZGF5c31cbiAgKi9cbiAgcmVhZG9ubHkgZGV2aWNlc0tleUR1cmF0aW9uRGF5cz86IG51bWJlcjtcbiAgLyoqXG4gICogV2hldGhlciBwcm92aXNpb25pbmcgb2YgSFRUUFMgY2VydGlmaWNhdGVzIGlzIGVuYWJsZWQgZm9yIHRoZSB0YWlsbmV0XG4gICpcbiAgKiBEb2NzIGF0IE9wZW5Ub2Z1IFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9zZWFyY2gub3BlbnRvZnUub3JnL3Byb3ZpZGVyL3RhaWxzY2FsZS90YWlsc2NhbGUvdjAuMjkuMi9kb2NzL3Jlc291cmNlcy90YWlsbmV0X3NldHRpbmdzI2h0dHBzX2VuYWJsZWQgVGFpbG5ldFNldHRpbmdzI2h0dHBzX2VuYWJsZWR9XG4gICovXG4gIHJlYWRvbmx5IGh0dHBzRW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogV2hldGhlciBuZXR3b3JrIGZsb3cgbG9ncyBhcmUgZW5hYmxlZCBmb3IgdGhlIHRhaWxuZXRcbiAgKlxuICAqIERvY3MgYXQgT3BlblRvZnUgUmVnaXN0cnk6IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MjbmV0d29ya19mbG93X2xvZ2dpbmdfb24gVGFpbG5ldFNldHRpbmdzI25ldHdvcmtfZmxvd19sb2dnaW5nX29ufVxuICAqL1xuICByZWFkb25seSBuZXR3b3JrRmxvd0xvZ2dpbmdPbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogV2hldGhlciBpZGVudGl0eSBjb2xsZWN0aW9uIGlzIGVuYWJsZWQgZm9yIGRldmljZSBwb3N0dXJlIGludGVncmF0aW9ucyBmb3IgdGhlIHRhaWxuZXRcbiAgKlxuICAqIERvY3MgYXQgT3BlblRvZnUgUmVnaXN0cnk6IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MjcG9zdHVyZV9pZGVudGl0eV9jb2xsZWN0aW9uX29uIFRhaWxuZXRTZXR0aW5ncyNwb3N0dXJlX2lkZW50aXR5X2NvbGxlY3Rpb25fb259XG4gICovXG4gIHJlYWRvbmx5IHBvc3R1cmVJZGVudGl0eUNvbGxlY3Rpb25Pbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTtcbiAgLyoqXG4gICogV2hldGhlciByZWdpb25hbCByb3V0aW5nIGlzIGVuYWJsZWQgZm9yIHRoZSB0YWlsbmV0XG4gICpcbiAgKiBEb2NzIGF0IE9wZW5Ub2Z1IFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9zZWFyY2gub3BlbnRvZnUub3JnL3Byb3ZpZGVyL3RhaWxzY2FsZS90YWlsc2NhbGUvdjAuMjkuMi9kb2NzL3Jlc291cmNlcy90YWlsbmV0X3NldHRpbmdzI3JlZ2lvbmFsX3JvdXRpbmdfb24gVGFpbG5ldFNldHRpbmdzI3JlZ2lvbmFsX3JvdXRpbmdfb259XG4gICovXG4gIHJlYWRvbmx5IHJlZ2lvbmFsUm91dGluZ09uPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBXaGV0aGVyIHVzZXIgYXBwcm92YWwgaXMgZW5hYmxlZCBmb3IgdGhpcyB0YWlsbmV0XG4gICpcbiAgKiBEb2NzIGF0IE9wZW5Ub2Z1IFJlZ2lzdHJ5OiB7QGxpbmsgaHR0cHM6Ly9zZWFyY2gub3BlbnRvZnUub3JnL3Byb3ZpZGVyL3RhaWxzY2FsZS90YWlsc2NhbGUvdjAuMjkuMi9kb2NzL3Jlc291cmNlcy90YWlsbmV0X3NldHRpbmdzI3VzZXJzX2FwcHJvdmFsX29uIFRhaWxuZXRTZXR0aW5ncyN1c2Vyc19hcHByb3ZhbF9vbn1cbiAgKi9cbiAgcmVhZG9ubHkgdXNlcnNBcHByb3ZhbE9uPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlO1xuICAvKipcbiAgKiBXaGljaCB1c2VyIHJvbGVzIGFyZSBhbGxvd2VkIHRvIGpvaW4gZXh0ZXJuYWwgdGFpbG5ldHNcbiAgKlxuICAqIERvY3MgYXQgT3BlblRvZnUgUmVnaXN0cnk6IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MjdXNlcnNfcm9sZV9hbGxvd2VkX3RvX2pvaW5fZXh0ZXJuYWxfdGFpbG5ldCBUYWlsbmV0U2V0dGluZ3MjdXNlcnNfcm9sZV9hbGxvd2VkX3RvX2pvaW5fZXh0ZXJuYWxfdGFpbG5ldH1cbiAgKi9cbiAgcmVhZG9ubHkgdXNlcnNSb2xlQWxsb3dlZFRvSm9pbkV4dGVybmFsVGFpbG5ldD86IHN0cmluZztcbn1cblxuLyoqXG4qIFJlcHJlc2VudHMgYSB7QGxpbmsgaHR0cHM6Ly9zZWFyY2gub3BlbnRvZnUub3JnL3Byb3ZpZGVyL3RhaWxzY2FsZS90YWlsc2NhbGUvdjAuMjkuMi9kb2NzL3Jlc291cmNlcy90YWlsbmV0X3NldHRpbmdzIHRhaWxzY2FsZV90YWlsbmV0X3NldHRpbmdzfVxuKi9cbmV4cG9ydCBjbGFzcyBUYWlsbmV0U2V0dGluZ3MgZXh0ZW5kcyBjZGt0bi5UZXJyYWZvcm1SZXNvdXJjZSB7XG5cbiAgLy8gPT09PT09PT09PT09PT09PT1cbiAgLy8gU1RBVElDIFBST1BFUlRJRVNcbiAgLy8gPT09PT09PT09PT09PT09PT1cbiAgcHVibGljIHN0YXRpYyByZWFkb25seSB0ZlJlc291cmNlVHlwZSA9IFwidGFpbHNjYWxlX3RhaWxuZXRfc2V0dGluZ3NcIjtcblxuICAvLyA9PT09PT09PT09PT09PVxuICAvLyBTVEFUSUMgTWV0aG9kc1xuICAvLyA9PT09PT09PT09PT09PVxuICAvKipcbiAgKiBHZW5lcmF0ZXMgQ0RLVE4gY29kZSBmb3IgaW1wb3J0aW5nIGEgVGFpbG5ldFNldHRpbmdzIHJlc291cmNlIHVwb24gcnVubmluZyBcImNka3RuIHBsYW4gPHN0YWNrLW5hbWU+XCJcbiAgKiBAcGFyYW0gc2NvcGUgVGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIGNvbnN0cnVjdFxuICAqIEBwYXJhbSBpbXBvcnRUb0lkIFRoZSBjb25zdHJ1Y3QgaWQgdXNlZCBpbiB0aGUgZ2VuZXJhdGVkIGNvbmZpZyBmb3IgdGhlIFRhaWxuZXRTZXR0aW5ncyB0byBpbXBvcnRcbiAgKiBAcGFyYW0gaW1wb3J0RnJvbUlkIFRoZSBpZCBvZiB0aGUgZXhpc3RpbmcgVGFpbG5ldFNldHRpbmdzIHRoYXQgc2hvdWxkIGJlIGltcG9ydGVkLiBSZWZlciB0byB0aGUge0BsaW5rIGh0dHBzOi8vc2VhcmNoLm9wZW50b2Z1Lm9yZy9wcm92aWRlci90YWlsc2NhbGUvdGFpbHNjYWxlL3YwLjI5LjIvZG9jcy9yZXNvdXJjZXMvdGFpbG5ldF9zZXR0aW5ncyNpbXBvcnQgaW1wb3J0IHNlY3Rpb259IGluIHRoZSBkb2N1bWVudGF0aW9uIG9mIHRoaXMgcmVzb3VyY2UgZm9yIHRoZSBpZCB0byB1c2VcbiAgKiBAcGFyYW0gcHJvdmlkZXI/IE9wdGlvbmFsIGluc3RhbmNlIG9mIHRoZSBwcm92aWRlciB3aGVyZSB0aGUgVGFpbG5ldFNldHRpbmdzIHRvIGltcG9ydCBpcyBmb3VuZFxuICAqL1xuICBwdWJsaWMgc3RhdGljIGdlbmVyYXRlQ29uZmlnRm9ySW1wb3J0KHNjb3BlOiBDb25zdHJ1Y3QsIGltcG9ydFRvSWQ6IHN0cmluZywgaW1wb3J0RnJvbUlkOiBzdHJpbmcsIHByb3ZpZGVyPzogY2RrdG4uVGVycmFmb3JtUHJvdmlkZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBjZGt0bi5JbXBvcnRhYmxlUmVzb3VyY2Uoc2NvcGUsIGltcG9ydFRvSWQsIHsgdGVycmFmb3JtUmVzb3VyY2VUeXBlOiBcInRhaWxzY2FsZV90YWlsbmV0X3NldHRpbmdzXCIsIGltcG9ydElkOiBpbXBvcnRGcm9tSWQsIHByb3ZpZGVyIH0pO1xuICAgICAgfVxuXG4gIC8vID09PT09PT09PT09XG4gIC8vIElOSVRJQUxJWkVSXG4gIC8vID09PT09PT09PT09XG5cbiAgLyoqXG4gICogQ3JlYXRlIGEgbmV3IHtAbGluayBodHRwczovL3NlYXJjaC5vcGVudG9mdS5vcmcvcHJvdmlkZXIvdGFpbHNjYWxlL3RhaWxzY2FsZS92MC4yOS4yL2RvY3MvcmVzb3VyY2VzL3RhaWxuZXRfc2V0dGluZ3MgdGFpbHNjYWxlX3RhaWxuZXRfc2V0dGluZ3N9IFJlc291cmNlXG4gICpcbiAgKiBAcGFyYW0gc2NvcGUgVGhlIHNjb3BlIGluIHdoaWNoIHRvIGRlZmluZSB0aGlzIGNvbnN0cnVjdFxuICAqIEBwYXJhbSBpZCBUaGUgc2NvcGVkIGNvbnN0cnVjdCBJRC4gTXVzdCBiZSB1bmlxdWUgYW1vbmdzdCBzaWJsaW5ncyBpbiB0aGUgc2FtZSBzY29wZVxuICAqIEBwYXJhbSBvcHRpb25zIFRhaWxuZXRTZXR0aW5nc0NvbmZpZyA9IHt9XG4gICovXG4gIHB1YmxpYyBjb25zdHJ1Y3RvcihzY29wZTogQ29uc3RydWN0LCBpZDogc3RyaW5nLCBjb25maWc6IFRhaWxuZXRTZXR0aW5nc0NvbmZpZyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkLCB7XG4gICAgICB0ZXJyYWZvcm1SZXNvdXJjZVR5cGU6ICd0YWlsc2NhbGVfdGFpbG5ldF9zZXR0aW5ncycsXG4gICAgICB0ZXJyYWZvcm1HZW5lcmF0b3JNZXRhZGF0YToge1xuICAgICAgICBwcm92aWRlck5hbWU6ICd0YWlsc2NhbGUnLFxuICAgICAgICBwcm92aWRlclZlcnNpb246ICcwLjI5LjInLFxuICAgICAgICBwcm92aWRlclZlcnNpb25Db25zdHJhaW50OiAnPTAuMjkuMidcbiAgICAgIH0sXG4gICAgICBwcm92aWRlcjogY29uZmlnLnByb3ZpZGVyLFxuICAgICAgZGVwZW5kc09uOiBjb25maWcuZGVwZW5kc09uLFxuICAgICAgY291bnQ6IGNvbmZpZy5jb3VudCxcbiAgICAgIGxpZmVjeWNsZTogY29uZmlnLmxpZmVjeWNsZSxcbiAgICAgIHByb3Zpc2lvbmVyczogY29uZmlnLnByb3Zpc2lvbmVycyxcbiAgICAgIGNvbm5lY3Rpb246IGNvbmZpZy5jb25uZWN0aW9uLFxuICAgICAgZm9yRWFjaDogY29uZmlnLmZvckVhY2hcbiAgICB9KTtcbiAgICB0aGlzLl9hY2xzRXh0ZXJuYWxMaW5rID0gY29uZmlnLmFjbHNFeHRlcm5hbExpbms7XG4gICAgdGhpcy5fYWNsc0V4dGVybmFsbHlNYW5hZ2VkT24gPSBjb25maWcuYWNsc0V4dGVybmFsbHlNYW5hZ2VkT247XG4gICAgdGhpcy5fZGV2aWNlc0FwcHJvdmFsT24gPSBjb25maWcuZGV2aWNlc0FwcHJvdmFsT247XG4gICAgdGhpcy5fZGV2aWNlc0F1dG9VcGRhdGVzT24gPSBjb25maWcuZGV2aWNlc0F1dG9VcGRhdGVzT247XG4gICAgdGhpcy5fZGV2aWNlc0tleUR1cmF0aW9uRGF5cyA9IGNvbmZpZy5kZXZpY2VzS2V5RHVyYXRpb25EYXlzO1xuICAgIHRoaXMuX2h0dHBzRW5hYmxlZCA9IGNvbmZpZy5odHRwc0VuYWJsZWQ7XG4gICAgdGhpcy5fbmV0d29ya0Zsb3dMb2dnaW5nT24gPSBjb25maWcubmV0d29ya0Zsb3dMb2dnaW5nT247XG4gICAgdGhpcy5fcG9zdHVyZUlkZW50aXR5Q29sbGVjdGlvbk9uID0gY29uZmlnLnBvc3R1cmVJZGVudGl0eUNvbGxlY3Rpb25PbjtcbiAgICB0aGlzLl9yZWdpb25hbFJvdXRpbmdPbiA9IGNvbmZpZy5yZWdpb25hbFJvdXRpbmdPbjtcbiAgICB0aGlzLl91c2Vyc0FwcHJvdmFsT24gPSBjb25maWcudXNlcnNBcHByb3ZhbE9uO1xuICAgIHRoaXMuX3VzZXJzUm9sZUFsbG93ZWRUb0pvaW5FeHRlcm5hbFRhaWxuZXQgPSBjb25maWcudXNlcnNSb2xlQWxsb3dlZFRvSm9pbkV4dGVybmFsVGFpbG5ldDtcbiAgfVxuXG4gIC8vID09PT09PT09PT1cbiAgLy8gQVRUUklCVVRFU1xuICAvLyA9PT09PT09PT09XG5cbiAgLy8gYWNsc19leHRlcm5hbF9saW5rIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfYWNsc0V4dGVybmFsTGluaz86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgYWNsc0V4dGVybmFsTGluaygpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ2FjbHNfZXh0ZXJuYWxfbGluaycpO1xuICB9XG4gIHB1YmxpYyBzZXQgYWNsc0V4dGVybmFsTGluayh2YWx1ZTogc3RyaW5nKSB7XG4gICAgdGhpcy5fYWNsc0V4dGVybmFsTGluayA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEFjbHNFeHRlcm5hbExpbmsoKSB7XG4gICAgdGhpcy5fYWNsc0V4dGVybmFsTGluayA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgYWNsc0V4dGVybmFsTGlua0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hY2xzRXh0ZXJuYWxMaW5rO1xuICB9XG5cbiAgLy8gYWNsc19leHRlcm5hbGx5X21hbmFnZWRfb24gLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9hY2xzRXh0ZXJuYWxseU1hbmFnZWRPbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgYWNsc0V4dGVybmFsbHlNYW5hZ2VkT24oKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnYWNsc19leHRlcm5hbGx5X21hbmFnZWRfb24nKTtcbiAgfVxuICBwdWJsaWMgc2V0IGFjbHNFeHRlcm5hbGx5TWFuYWdlZE9uKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9hY2xzRXh0ZXJuYWxseU1hbmFnZWRPbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldEFjbHNFeHRlcm5hbGx5TWFuYWdlZE9uKCkge1xuICAgIHRoaXMuX2FjbHNFeHRlcm5hbGx5TWFuYWdlZE9uID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBhY2xzRXh0ZXJuYWxseU1hbmFnZWRPbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9hY2xzRXh0ZXJuYWxseU1hbmFnZWRPbjtcbiAgfVxuXG4gIC8vIGRldmljZXNfYXBwcm92YWxfb24gLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9kZXZpY2VzQXBwcm92YWxPbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgZGV2aWNlc0FwcHJvdmFsT24oKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnZGV2aWNlc19hcHByb3ZhbF9vbicpO1xuICB9XG4gIHB1YmxpYyBzZXQgZGV2aWNlc0FwcHJvdmFsT24odmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX2RldmljZXNBcHByb3ZhbE9uID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0RGV2aWNlc0FwcHJvdmFsT24oKSB7XG4gICAgdGhpcy5fZGV2aWNlc0FwcHJvdmFsT24gPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IGRldmljZXNBcHByb3ZhbE9uSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RldmljZXNBcHByb3ZhbE9uO1xuICB9XG5cbiAgLy8gZGV2aWNlc19hdXRvX3VwZGF0ZXNfb24gLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9kZXZpY2VzQXV0b1VwZGF0ZXNPbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgZGV2aWNlc0F1dG9VcGRhdGVzT24oKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnZGV2aWNlc19hdXRvX3VwZGF0ZXNfb24nKTtcbiAgfVxuICBwdWJsaWMgc2V0IGRldmljZXNBdXRvVXBkYXRlc09uKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9kZXZpY2VzQXV0b1VwZGF0ZXNPbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldERldmljZXNBdXRvVXBkYXRlc09uKCkge1xuICAgIHRoaXMuX2RldmljZXNBdXRvVXBkYXRlc09uID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBkZXZpY2VzQXV0b1VwZGF0ZXNPbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9kZXZpY2VzQXV0b1VwZGF0ZXNPbjtcbiAgfVxuXG4gIC8vIGRldmljZXNfa2V5X2R1cmF0aW9uX2RheXMgLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9kZXZpY2VzS2V5RHVyYXRpb25EYXlzPzogbnVtYmVyOyBcbiAgcHVibGljIGdldCBkZXZpY2VzS2V5RHVyYXRpb25EYXlzKCkge1xuICAgIHJldHVybiB0aGlzLmdldE51bWJlckF0dHJpYnV0ZSgnZGV2aWNlc19rZXlfZHVyYXRpb25fZGF5cycpO1xuICB9XG4gIHB1YmxpYyBzZXQgZGV2aWNlc0tleUR1cmF0aW9uRGF5cyh2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy5fZGV2aWNlc0tleUR1cmF0aW9uRGF5cyA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldERldmljZXNLZXlEdXJhdGlvbkRheXMoKSB7XG4gICAgdGhpcy5fZGV2aWNlc0tleUR1cmF0aW9uRGF5cyA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgZGV2aWNlc0tleUR1cmF0aW9uRGF5c0lucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9kZXZpY2VzS2V5RHVyYXRpb25EYXlzO1xuICB9XG5cbiAgLy8gaHR0cHNfZW5hYmxlZCAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX2h0dHBzRW5hYmxlZD86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgaHR0cHNFbmFibGVkKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ2h0dHBzX2VuYWJsZWQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IGh0dHBzRW5hYmxlZCh2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5faHR0cHNFbmFibGVkID0gdmFsdWU7XG4gIH1cbiAgcHVibGljIHJlc2V0SHR0cHNFbmFibGVkKCkge1xuICAgIHRoaXMuX2h0dHBzRW5hYmxlZCA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgaHR0cHNFbmFibGVkSW5wdXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2h0dHBzRW5hYmxlZDtcbiAgfVxuXG4gIC8vIGlkIC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiBmYWxzZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHB1YmxpYyBnZXQgaWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3RyaW5nQXR0cmlidXRlKCdpZCcpO1xuICB9XG5cbiAgLy8gbmV0d29ya19mbG93X2xvZ2dpbmdfb24gLSBjb21wdXRlZDogdHJ1ZSwgb3B0aW9uYWw6IHRydWUsIHJlcXVpcmVkOiBmYWxzZVxuICBwcml2YXRlIF9uZXR3b3JrRmxvd0xvZ2dpbmdPbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgbmV0d29ya0Zsb3dMb2dnaW5nT24oKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Qm9vbGVhbkF0dHJpYnV0ZSgnbmV0d29ya19mbG93X2xvZ2dpbmdfb24nKTtcbiAgfVxuICBwdWJsaWMgc2V0IG5ldHdvcmtGbG93TG9nZ2luZ09uKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9uZXR3b3JrRmxvd0xvZ2dpbmdPbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldE5ldHdvcmtGbG93TG9nZ2luZ09uKCkge1xuICAgIHRoaXMuX25ldHdvcmtGbG93TG9nZ2luZ09uID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBuZXR3b3JrRmxvd0xvZ2dpbmdPbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl9uZXR3b3JrRmxvd0xvZ2dpbmdPbjtcbiAgfVxuXG4gIC8vIHBvc3R1cmVfaWRlbnRpdHlfY29sbGVjdGlvbl9vbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3Bvc3R1cmVJZGVudGl0eUNvbGxlY3Rpb25Pbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgcG9zdHVyZUlkZW50aXR5Q29sbGVjdGlvbk9uKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ3Bvc3R1cmVfaWRlbnRpdHlfY29sbGVjdGlvbl9vbicpO1xuICB9XG4gIHB1YmxpYyBzZXQgcG9zdHVyZUlkZW50aXR5Q29sbGVjdGlvbk9uKHZhbHVlOiBib29sZWFuIHwgY2RrdG4uSVJlc29sdmFibGUpIHtcbiAgICB0aGlzLl9wb3N0dXJlSWRlbnRpdHlDb2xsZWN0aW9uT24gPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRQb3N0dXJlSWRlbnRpdHlDb2xsZWN0aW9uT24oKSB7XG4gICAgdGhpcy5fcG9zdHVyZUlkZW50aXR5Q29sbGVjdGlvbk9uID0gdW5kZWZpbmVkO1xuICB9XG4gIC8vIFRlbXBvcmFyaWx5IGV4cG9zZSBpbnB1dCB2YWx1ZS4gVXNlIHdpdGggY2F1dGlvbi5cbiAgcHVibGljIGdldCBwb3N0dXJlSWRlbnRpdHlDb2xsZWN0aW9uT25JbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcG9zdHVyZUlkZW50aXR5Q29sbGVjdGlvbk9uO1xuICB9XG5cbiAgLy8gcmVnaW9uYWxfcm91dGluZ19vbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3JlZ2lvbmFsUm91dGluZ09uPzogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlOyBcbiAgcHVibGljIGdldCByZWdpb25hbFJvdXRpbmdPbigpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRCb29sZWFuQXR0cmlidXRlKCdyZWdpb25hbF9yb3V0aW5nX29uJyk7XG4gIH1cbiAgcHVibGljIHNldCByZWdpb25hbFJvdXRpbmdPbih2YWx1ZTogYm9vbGVhbiB8IGNka3RuLklSZXNvbHZhYmxlKSB7XG4gICAgdGhpcy5fcmVnaW9uYWxSb3V0aW5nT24gPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRSZWdpb25hbFJvdXRpbmdPbigpIHtcbiAgICB0aGlzLl9yZWdpb25hbFJvdXRpbmdPbiA9IHVuZGVmaW5lZDtcbiAgfVxuICAvLyBUZW1wb3JhcmlseSBleHBvc2UgaW5wdXQgdmFsdWUuIFVzZSB3aXRoIGNhdXRpb24uXG4gIHB1YmxpYyBnZXQgcmVnaW9uYWxSb3V0aW5nT25JbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVnaW9uYWxSb3V0aW5nT247XG4gIH1cblxuICAvLyB1c2Vyc19hcHByb3ZhbF9vbiAtIGNvbXB1dGVkOiB0cnVlLCBvcHRpb25hbDogdHJ1ZSwgcmVxdWlyZWQ6IGZhbHNlXG4gIHByaXZhdGUgX3VzZXJzQXBwcm92YWxPbj86IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZTsgXG4gIHB1YmxpYyBnZXQgdXNlcnNBcHByb3ZhbE9uKCkge1xuICAgIHJldHVybiB0aGlzLmdldEJvb2xlYW5BdHRyaWJ1dGUoJ3VzZXJzX2FwcHJvdmFsX29uJyk7XG4gIH1cbiAgcHVibGljIHNldCB1c2Vyc0FwcHJvdmFsT24odmFsdWU6IGJvb2xlYW4gfCBjZGt0bi5JUmVzb2x2YWJsZSkge1xuICAgIHRoaXMuX3VzZXJzQXBwcm92YWxPbiA9IHZhbHVlO1xuICB9XG4gIHB1YmxpYyByZXNldFVzZXJzQXBwcm92YWxPbigpIHtcbiAgICB0aGlzLl91c2Vyc0FwcHJvdmFsT24gPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHVzZXJzQXBwcm92YWxPbklucHV0KCkge1xuICAgIHJldHVybiB0aGlzLl91c2Vyc0FwcHJvdmFsT247XG4gIH1cblxuICAvLyB1c2Vyc19yb2xlX2FsbG93ZWRfdG9fam9pbl9leHRlcm5hbF90YWlsbmV0IC0gY29tcHV0ZWQ6IHRydWUsIG9wdGlvbmFsOiB0cnVlLCByZXF1aXJlZDogZmFsc2VcbiAgcHJpdmF0ZSBfdXNlcnNSb2xlQWxsb3dlZFRvSm9pbkV4dGVybmFsVGFpbG5ldD86IHN0cmluZzsgXG4gIHB1YmxpYyBnZXQgdXNlcnNSb2xlQWxsb3dlZFRvSm9pbkV4dGVybmFsVGFpbG5ldCgpIHtcbiAgICByZXR1cm4gdGhpcy5nZXRTdHJpbmdBdHRyaWJ1dGUoJ3VzZXJzX3JvbGVfYWxsb3dlZF90b19qb2luX2V4dGVybmFsX3RhaWxuZXQnKTtcbiAgfVxuICBwdWJsaWMgc2V0IHVzZXJzUm9sZUFsbG93ZWRUb0pvaW5FeHRlcm5hbFRhaWxuZXQodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuX3VzZXJzUm9sZUFsbG93ZWRUb0pvaW5FeHRlcm5hbFRhaWxuZXQgPSB2YWx1ZTtcbiAgfVxuICBwdWJsaWMgcmVzZXRVc2Vyc1JvbGVBbGxvd2VkVG9Kb2luRXh0ZXJuYWxUYWlsbmV0KCkge1xuICAgIHRoaXMuX3VzZXJzUm9sZUFsbG93ZWRUb0pvaW5FeHRlcm5hbFRhaWxuZXQgPSB1bmRlZmluZWQ7XG4gIH1cbiAgLy8gVGVtcG9yYXJpbHkgZXhwb3NlIGlucHV0IHZhbHVlLiBVc2Ugd2l0aCBjYXV0aW9uLlxuICBwdWJsaWMgZ2V0IHVzZXJzUm9sZUFsbG93ZWRUb0pvaW5FeHRlcm5hbFRhaWxuZXRJbnB1dCgpIHtcbiAgICByZXR1cm4gdGhpcy5fdXNlcnNSb2xlQWxsb3dlZFRvSm9pbkV4dGVybmFsVGFpbG5ldDtcbiAgfVxuXG4gIC8vID09PT09PT09PVxuICAvLyBTWU5USEVTSVNcbiAgLy8gPT09PT09PT09XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICByZXR1cm4ge1xuICAgICAgYWNsc19leHRlcm5hbF9saW5rOiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl9hY2xzRXh0ZXJuYWxMaW5rKSxcbiAgICAgIGFjbHNfZXh0ZXJuYWxseV9tYW5hZ2VkX29uOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fYWNsc0V4dGVybmFsbHlNYW5hZ2VkT24pLFxuICAgICAgZGV2aWNlc19hcHByb3ZhbF9vbjogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX2RldmljZXNBcHByb3ZhbE9uKSxcbiAgICAgIGRldmljZXNfYXV0b191cGRhdGVzX29uOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fZGV2aWNlc0F1dG9VcGRhdGVzT24pLFxuICAgICAgZGV2aWNlc19rZXlfZHVyYXRpb25fZGF5czogY2RrdG4ubnVtYmVyVG9UZXJyYWZvcm0odGhpcy5fZGV2aWNlc0tleUR1cmF0aW9uRGF5cyksXG4gICAgICBodHRwc19lbmFibGVkOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5faHR0cHNFbmFibGVkKSxcbiAgICAgIG5ldHdvcmtfZmxvd19sb2dnaW5nX29uOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fbmV0d29ya0Zsb3dMb2dnaW5nT24pLFxuICAgICAgcG9zdHVyZV9pZGVudGl0eV9jb2xsZWN0aW9uX29uOiBjZGt0bi5ib29sZWFuVG9UZXJyYWZvcm0odGhpcy5fcG9zdHVyZUlkZW50aXR5Q29sbGVjdGlvbk9uKSxcbiAgICAgIHJlZ2lvbmFsX3JvdXRpbmdfb246IGNka3RuLmJvb2xlYW5Ub1RlcnJhZm9ybSh0aGlzLl9yZWdpb25hbFJvdXRpbmdPbiksXG4gICAgICB1c2Vyc19hcHByb3ZhbF9vbjogY2RrdG4uYm9vbGVhblRvVGVycmFmb3JtKHRoaXMuX3VzZXJzQXBwcm92YWxPbiksXG4gICAgICB1c2Vyc19yb2xlX2FsbG93ZWRfdG9fam9pbl9leHRlcm5hbF90YWlsbmV0OiBjZGt0bi5zdHJpbmdUb1RlcnJhZm9ybSh0aGlzLl91c2Vyc1JvbGVBbGxvd2VkVG9Kb2luRXh0ZXJuYWxUYWlsbmV0KSxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIHN5bnRoZXNpemVIY2xBdHRyaWJ1dGVzKCk6IHsgW25hbWU6IHN0cmluZ106IGFueSB9IHtcbiAgICBjb25zdCBhdHRycyA9IHtcbiAgICAgIGFjbHNfZXh0ZXJuYWxfbGluazoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uc3RyaW5nVG9IY2xUZXJyYWZvcm0odGhpcy5fYWNsc0V4dGVybmFsTGluayksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcInN0cmluZ1wiLFxuICAgICAgfSxcbiAgICAgIGFjbHNfZXh0ZXJuYWxseV9tYW5hZ2VkX29uOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fYWNsc0V4dGVybmFsbHlNYW5hZ2VkT24pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgZGV2aWNlc19hcHByb3ZhbF9vbjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX2RldmljZXNBcHByb3ZhbE9uKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIGRldmljZXNfYXV0b191cGRhdGVzX29uOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fZGV2aWNlc0F1dG9VcGRhdGVzT24pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgZGV2aWNlc19rZXlfZHVyYXRpb25fZGF5czoge1xuICAgICAgICB2YWx1ZTogY2RrdG4ubnVtYmVyVG9IY2xUZXJyYWZvcm0odGhpcy5fZGV2aWNlc0tleUR1cmF0aW9uRGF5cyksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcIm51bWJlclwiLFxuICAgICAgfSxcbiAgICAgIGh0dHBzX2VuYWJsZWQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9odHRwc0VuYWJsZWQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgbmV0d29ya19mbG93X2xvZ2dpbmdfb246IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9uZXR3b3JrRmxvd0xvZ2dpbmdPbiksXG4gICAgICAgIGlzQmxvY2s6IGZhbHNlLFxuICAgICAgICB0eXBlOiBcInNpbXBsZVwiLFxuICAgICAgICBzdG9yYWdlQ2xhc3NUeXBlOiBcImJvb2xlYW5cIixcbiAgICAgIH0sXG4gICAgICBwb3N0dXJlX2lkZW50aXR5X2NvbGxlY3Rpb25fb246IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLmJvb2xlYW5Ub0hjbFRlcnJhZm9ybSh0aGlzLl9wb3N0dXJlSWRlbnRpdHlDb2xsZWN0aW9uT24pLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJib29sZWFuXCIsXG4gICAgICB9LFxuICAgICAgcmVnaW9uYWxfcm91dGluZ19vbjoge1xuICAgICAgICB2YWx1ZTogY2RrdG4uYm9vbGVhblRvSGNsVGVycmFmb3JtKHRoaXMuX3JlZ2lvbmFsUm91dGluZ09uKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIHVzZXJzX2FwcHJvdmFsX29uOiB7XG4gICAgICAgIHZhbHVlOiBjZGt0bi5ib29sZWFuVG9IY2xUZXJyYWZvcm0odGhpcy5fdXNlcnNBcHByb3ZhbE9uKSxcbiAgICAgICAgaXNCbG9jazogZmFsc2UsXG4gICAgICAgIHR5cGU6IFwic2ltcGxlXCIsXG4gICAgICAgIHN0b3JhZ2VDbGFzc1R5cGU6IFwiYm9vbGVhblwiLFxuICAgICAgfSxcbiAgICAgIHVzZXJzX3JvbGVfYWxsb3dlZF90b19qb2luX2V4dGVybmFsX3RhaWxuZXQ6IHtcbiAgICAgICAgdmFsdWU6IGNka3RuLnN0cmluZ1RvSGNsVGVycmFmb3JtKHRoaXMuX3VzZXJzUm9sZUFsbG93ZWRUb0pvaW5FeHRlcm5hbFRhaWxuZXQpLFxuICAgICAgICBpc0Jsb2NrOiBmYWxzZSxcbiAgICAgICAgdHlwZTogXCJzaW1wbGVcIixcbiAgICAgICAgc3RvcmFnZUNsYXNzVHlwZTogXCJzdHJpbmdcIixcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIC8vIHJlbW92ZSB1bmRlZmluZWQgYXR0cmlidXRlc1xuICAgIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoYXR0cnMpLmZpbHRlcigoW18sIHZhbHVlXSkgPT4gdmFsdWUgIT09IHVuZGVmaW5lZCAmJiB2YWx1ZS52YWx1ZSAhPT0gdW5kZWZpbmVkICkpXG4gIH1cbn1cbiJdfQ==