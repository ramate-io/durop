# `tailscale_contacts`

Refer to the OpenTofu Registry for docs: [`tailscale_contacts`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts).
