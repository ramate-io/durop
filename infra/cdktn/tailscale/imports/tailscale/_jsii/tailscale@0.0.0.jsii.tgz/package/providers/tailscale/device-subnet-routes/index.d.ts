import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DeviceSubnetRoutesConfig extends cdktn.TerraformMetaArguments {
    /**
    * The device to set subnet routes for
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_subnet_routes#device_id DeviceSubnetRoutes#device_id}
    */
    readonly deviceId: string;
    /**
    * The subnet routes that are enabled to be routed by a device
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_subnet_routes#routes DeviceSubnetRoutes#routes}
    */
    readonly routes: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_subnet_routes tailscale_device_subnet_routes}
*/
export declare class DeviceSubnetRoutes extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_device_subnet_routes";
    /**
    * Generates CDKTN code for importing a DeviceSubnetRoutes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeviceSubnetRoutes to import
    * @param importFromId The id of the existing DeviceSubnetRoutes that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_subnet_routes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeviceSubnetRoutes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_subnet_routes tailscale_device_subnet_routes} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeviceSubnetRoutesConfig
    */
    constructor(scope: Construct, id: string, config: DeviceSubnetRoutesConfig);
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    get deviceIdInput(): string | undefined;
    get id(): string;
    private _routes?;
    get routes(): string[];
    set routes(value: string[]);
    get routesInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
