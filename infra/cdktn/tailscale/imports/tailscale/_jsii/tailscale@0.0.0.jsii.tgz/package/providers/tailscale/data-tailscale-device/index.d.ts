import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTailscaleDeviceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The short hostname of the device
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/device#hostname DataTailscaleDevice#hostname}
    */
    readonly hostname?: string;
    /**
    * The full name of the device (e.g. `hostname.domain.ts.net`)
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/device#name DataTailscaleDevice#name}
    */
    readonly name?: string;
    /**
    * If specified, the provider will make multiple attempts to obtain the data source until the wait_for duration is reached. Retries are made every second so this value should be greater than 1s
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/device#wait_for DataTailscaleDevice#wait_for}
    */
    readonly waitFor?: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/device tailscale_device}
*/
export declare class DataTailscaleDevice extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tailscale_device";
    /**
    * Generates CDKTN code for importing a DataTailscaleDevice resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTailscaleDevice to import
    * @param importFromId The id of the existing DataTailscaleDevice that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/device#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTailscaleDevice to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/device tailscale_device} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTailscaleDeviceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTailscaleDeviceConfig);
    get addresses(): string[];
    get authorized(): cdktn.IResolvable;
    get blocksIncomingConnections(): cdktn.IResolvable;
    get clientVersion(): string;
    get created(): string;
    get expires(): string;
    private _hostname?;
    get hostname(): string;
    set hostname(value: string);
    resetHostname(): void;
    get hostnameInput(): string | undefined;
    get id(): string;
    get isExternal(): cdktn.IResolvable;
    get keyExpiryDisabled(): cdktn.IResolvable;
    get lastSeen(): string;
    get machineKey(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get nodeId(): string;
    get nodeKey(): string;
    get os(): string;
    get tags(): string[];
    get tailnetLockError(): string;
    get tailnetLockKey(): string;
    get updateAvailable(): cdktn.IResolvable;
    get user(): string;
    private _waitFor?;
    get waitFor(): string;
    set waitFor(value: string);
    resetWaitFor(): void;
    get waitForInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
