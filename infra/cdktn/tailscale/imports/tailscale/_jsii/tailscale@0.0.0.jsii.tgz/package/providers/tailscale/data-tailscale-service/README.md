# `data_tailscale_service`

Refer to the OpenTofu Registry for docs: [`data_tailscale_service`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/service).
