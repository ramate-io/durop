import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTailscaleUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier for the user.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/user#id DataTailscaleUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The emailish login name of the user.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/user#login_name DataTailscaleUser#login_name}
    */
    readonly loginName?: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/user tailscale_user}
*/
export declare class DataTailscaleUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tailscale_user";
    /**
    * Generates CDKTN code for importing a DataTailscaleUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTailscaleUser to import
    * @param importFromId The id of the existing DataTailscaleUser that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTailscaleUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/user tailscale_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTailscaleUserConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTailscaleUserConfig);
    get created(): string;
    get currentlyConnected(): cdktn.IResolvable;
    get deviceCount(): number;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastSeen(): string;
    private _loginName?;
    get loginName(): string;
    set loginName(value: string);
    resetLoginName(): void;
    get loginNameInput(): string | undefined;
    get profilePicUrl(): string;
    get role(): string;
    get status(): string;
    get tailnetId(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
