import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TailnetSettingsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Link to your external ACL definition or management system. Must be a valid URL.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#acls_external_link TailnetSettings#acls_external_link}
    */
    readonly aclsExternalLink?: string;
    /**
    * Prevent users from editing policies in the admin console to avoid conflicts with external management workflows like GitOps or Terraform.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#acls_externally_managed_on TailnetSettings#acls_externally_managed_on}
    */
    readonly aclsExternallyManagedOn?: boolean | cdktn.IResolvable;
    /**
    * Whether device approval is enabled for the tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#devices_approval_on TailnetSettings#devices_approval_on}
    */
    readonly devicesApprovalOn?: boolean | cdktn.IResolvable;
    /**
    * Whether auto updates are enabled for devices that belong to this tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#devices_auto_updates_on TailnetSettings#devices_auto_updates_on}
    */
    readonly devicesAutoUpdatesOn?: boolean | cdktn.IResolvable;
    /**
    * The key expiry duration for devices on this tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#devices_key_duration_days TailnetSettings#devices_key_duration_days}
    */
    readonly devicesKeyDurationDays?: number;
    /**
    * Whether provisioning of HTTPS certificates is enabled for the tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#https_enabled TailnetSettings#https_enabled}
    */
    readonly httpsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether network flow logs are enabled for the tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#network_flow_logging_on TailnetSettings#network_flow_logging_on}
    */
    readonly networkFlowLoggingOn?: boolean | cdktn.IResolvable;
    /**
    * Whether identity collection is enabled for device posture integrations for the tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#posture_identity_collection_on TailnetSettings#posture_identity_collection_on}
    */
    readonly postureIdentityCollectionOn?: boolean | cdktn.IResolvable;
    /**
    * Whether regional routing is enabled for the tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#regional_routing_on TailnetSettings#regional_routing_on}
    */
    readonly regionalRoutingOn?: boolean | cdktn.IResolvable;
    /**
    * Whether user approval is enabled for this tailnet
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#users_approval_on TailnetSettings#users_approval_on}
    */
    readonly usersApprovalOn?: boolean | cdktn.IResolvable;
    /**
    * Which user roles are allowed to join external tailnets
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#users_role_allowed_to_join_external_tailnet TailnetSettings#users_role_allowed_to_join_external_tailnet}
    */
    readonly usersRoleAllowedToJoinExternalTailnet?: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings tailscale_tailnet_settings}
*/
export declare class TailnetSettings extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_tailnet_settings";
    /**
    * Generates CDKTN code for importing a TailnetSettings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TailnetSettings to import
    * @param importFromId The id of the existing TailnetSettings that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TailnetSettings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_settings tailscale_tailnet_settings} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TailnetSettingsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TailnetSettingsConfig);
    private _aclsExternalLink?;
    get aclsExternalLink(): string;
    set aclsExternalLink(value: string);
    resetAclsExternalLink(): void;
    get aclsExternalLinkInput(): string | undefined;
    private _aclsExternallyManagedOn?;
    get aclsExternallyManagedOn(): boolean | cdktn.IResolvable;
    set aclsExternallyManagedOn(value: boolean | cdktn.IResolvable);
    resetAclsExternallyManagedOn(): void;
    get aclsExternallyManagedOnInput(): boolean | cdktn.IResolvable | undefined;
    private _devicesApprovalOn?;
    get devicesApprovalOn(): boolean | cdktn.IResolvable;
    set devicesApprovalOn(value: boolean | cdktn.IResolvable);
    resetDevicesApprovalOn(): void;
    get devicesApprovalOnInput(): boolean | cdktn.IResolvable | undefined;
    private _devicesAutoUpdatesOn?;
    get devicesAutoUpdatesOn(): boolean | cdktn.IResolvable;
    set devicesAutoUpdatesOn(value: boolean | cdktn.IResolvable);
    resetDevicesAutoUpdatesOn(): void;
    get devicesAutoUpdatesOnInput(): boolean | cdktn.IResolvable | undefined;
    private _devicesKeyDurationDays?;
    get devicesKeyDurationDays(): number;
    set devicesKeyDurationDays(value: number);
    resetDevicesKeyDurationDays(): void;
    get devicesKeyDurationDaysInput(): number | undefined;
    private _httpsEnabled?;
    get httpsEnabled(): boolean | cdktn.IResolvable;
    set httpsEnabled(value: boolean | cdktn.IResolvable);
    resetHttpsEnabled(): void;
    get httpsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    private _networkFlowLoggingOn?;
    get networkFlowLoggingOn(): boolean | cdktn.IResolvable;
    set networkFlowLoggingOn(value: boolean | cdktn.IResolvable);
    resetNetworkFlowLoggingOn(): void;
    get networkFlowLoggingOnInput(): boolean | cdktn.IResolvable | undefined;
    private _postureIdentityCollectionOn?;
    get postureIdentityCollectionOn(): boolean | cdktn.IResolvable;
    set postureIdentityCollectionOn(value: boolean | cdktn.IResolvable);
    resetPostureIdentityCollectionOn(): void;
    get postureIdentityCollectionOnInput(): boolean | cdktn.IResolvable | undefined;
    private _regionalRoutingOn?;
    get regionalRoutingOn(): boolean | cdktn.IResolvable;
    set regionalRoutingOn(value: boolean | cdktn.IResolvable);
    resetRegionalRoutingOn(): void;
    get regionalRoutingOnInput(): boolean | cdktn.IResolvable | undefined;
    private _usersApprovalOn?;
    get usersApprovalOn(): boolean | cdktn.IResolvable;
    set usersApprovalOn(value: boolean | cdktn.IResolvable);
    resetUsersApprovalOn(): void;
    get usersApprovalOnInput(): boolean | cdktn.IResolvable | undefined;
    private _usersRoleAllowedToJoinExternalTailnet?;
    get usersRoleAllowedToJoinExternalTailnet(): string;
    set usersRoleAllowedToJoinExternalTailnet(value: string);
    resetUsersRoleAllowedToJoinExternalTailnet(): void;
    get usersRoleAllowedToJoinExternalTailnetInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
