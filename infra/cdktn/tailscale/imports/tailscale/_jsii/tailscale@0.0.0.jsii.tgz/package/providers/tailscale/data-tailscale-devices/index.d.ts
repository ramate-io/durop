import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTailscaleDevicesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filters the device list to elements whose name has the provided prefix
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices#name_prefix DataTailscaleDevices#name_prefix}
    */
    readonly namePrefix?: string;
    /**
    * devices block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices#devices DataTailscaleDevices#devices}
    */
    readonly devices?: DataTailscaleDevicesDevices[] | cdktn.IResolvable;
    /**
    * filter block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices#filter DataTailscaleDevices#filter}
    */
    readonly filter?: DataTailscaleDevicesFilter[] | cdktn.IResolvable;
}
export interface DataTailscaleDevicesDevices {
}
export declare function dataTailscaleDevicesDevicesToTerraform(struct?: DataTailscaleDevicesDevices | cdktn.IResolvable): any;
export declare function dataTailscaleDevicesDevicesToHclTerraform(struct?: DataTailscaleDevicesDevices | cdktn.IResolvable): any;
export declare class DataTailscaleDevicesDevicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTailscaleDevicesDevices | cdktn.IResolvable | undefined;
    set internalValue(value: DataTailscaleDevicesDevices | cdktn.IResolvable | undefined);
    get addresses(): string[];
    get authorized(): cdktn.IResolvable;
    get blocksIncomingConnections(): cdktn.IResolvable;
    get clientVersion(): string;
    get created(): string;
    get expires(): string;
    get hostname(): string;
    get id(): string;
    get isExternal(): cdktn.IResolvable;
    get keyExpiryDisabled(): cdktn.IResolvable;
    get lastSeen(): string;
    get machineKey(): string;
    get name(): string;
    get nodeId(): string;
    get nodeKey(): string;
    get os(): string;
    get tags(): string[];
    get tailnetLockError(): string;
    get tailnetLockKey(): string;
    get updateAvailable(): cdktn.IResolvable;
    get user(): string;
}
export declare class DataTailscaleDevicesDevicesList extends cdktn.ComplexList {
    internalValue?: DataTailscaleDevicesDevices[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTailscaleDevicesDevicesOutputReference;
}
export interface DataTailscaleDevicesFilter {
    /**
    * The name must be a top-level device property, e.g. isEphemeral, tags, hostname, etc.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices#name DataTailscaleDevices#name}
    */
    readonly name: string;
    /**
    * The list of values to filter for. Values are matched as exact matches.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices#values DataTailscaleDevices#values}
    */
    readonly values: string[];
}
export declare function dataTailscaleDevicesFilterToTerraform(struct?: DataTailscaleDevicesFilter | cdktn.IResolvable): any;
export declare function dataTailscaleDevicesFilterToHclTerraform(struct?: DataTailscaleDevicesFilter | cdktn.IResolvable): any;
export declare class DataTailscaleDevicesFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTailscaleDevicesFilter | cdktn.IResolvable | undefined;
    set internalValue(value: DataTailscaleDevicesFilter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class DataTailscaleDevicesFilterList extends cdktn.ComplexList {
    internalValue?: DataTailscaleDevicesFilter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTailscaleDevicesFilterOutputReference;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices tailscale_devices}
*/
export declare class DataTailscaleDevices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tailscale_devices";
    /**
    * Generates CDKTN code for importing a DataTailscaleDevices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTailscaleDevices to import
    * @param importFromId The id of the existing DataTailscaleDevices that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTailscaleDevices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices tailscale_devices} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTailscaleDevicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTailscaleDevicesConfig);
    get id(): string;
    private _namePrefix?;
    get namePrefix(): string;
    set namePrefix(value: string);
    resetNamePrefix(): void;
    get namePrefixInput(): string | undefined;
    private _devices;
    get devices(): DataTailscaleDevicesDevicesList;
    putDevices(value: DataTailscaleDevicesDevices[] | cdktn.IResolvable): void;
    resetDevices(): void;
    get devicesInput(): cdktn.IResolvable | DataTailscaleDevicesDevices[] | undefined;
    private _filter;
    get filter(): DataTailscaleDevicesFilterList;
    putFilter(value: DataTailscaleDevicesFilter[] | cdktn.IResolvable): void;
    resetFilter(): void;
    get filterInput(): cdktn.IResolvable | DataTailscaleDevicesFilter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
