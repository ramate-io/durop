import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AclConfig extends cdktn.TerraformMetaArguments {
    /**
    * The policy that defines which devices and users are allowed to connect in your network. Can be either a JSON or a HuJSON string.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/acl#acl Acl#acl}
    */
    readonly acl: string;
    /**
    * If true, will skip requirement to import acl before allowing changes. Be careful, can cause the policy file to be overwritten
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/acl#overwrite_existing_content Acl#overwrite_existing_content}
    */
    readonly overwriteExistingContent?: boolean | cdktn.IResolvable;
    /**
    * If true, will reset the policy file for the Tailnet to the default when this resource is destroyed
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/acl#reset_acl_on_destroy Acl#reset_acl_on_destroy}
    */
    readonly resetAclOnDestroy?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/acl tailscale_acl}
*/
export declare class Acl extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_acl";
    /**
    * Generates CDKTN code for importing a Acl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Acl to import
    * @param importFromId The id of the existing Acl that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Acl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/acl tailscale_acl} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AclConfig
    */
    constructor(scope: Construct, id: string, config: AclConfig);
    private _acl?;
    get acl(): string;
    set acl(value: string);
    get aclInput(): string | undefined;
    get id(): string;
    private _overwriteExistingContent?;
    get overwriteExistingContent(): boolean | cdktn.IResolvable;
    set overwriteExistingContent(value: boolean | cdktn.IResolvable);
    resetOverwriteExistingContent(): void;
    get overwriteExistingContentInput(): boolean | cdktn.IResolvable | undefined;
    private _resetAclOnDestroy?;
    get resetAclOnDestroy(): boolean | cdktn.IResolvable;
    set resetAclOnDestroy(value: boolean | cdktn.IResolvable);
    resetResetAclOnDestroy(): void;
    get resetAclOnDestroyInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
