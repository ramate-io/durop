# `tailscale_tailnet_key`

Refer to the OpenTofu Registry for docs: [`tailscale_tailnet_key`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/tailnet_key).
