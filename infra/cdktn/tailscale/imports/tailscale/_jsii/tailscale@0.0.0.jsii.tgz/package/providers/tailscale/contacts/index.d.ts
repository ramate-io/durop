import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ContactsConfig extends cdktn.TerraformMetaArguments {
    /**
    * account block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts#account Contacts#account}
    */
    readonly account?: ContactsAccount[] | cdktn.IResolvable;
    /**
    * security block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts#security Contacts#security}
    */
    readonly security?: ContactsSecurity[] | cdktn.IResolvable;
    /**
    * support block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts#support Contacts#support}
    */
    readonly support?: ContactsSupport[] | cdktn.IResolvable;
}
export interface ContactsAccount {
    /**
    * Email address to send communications to
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts#email Contacts#email}
    */
    readonly email: string;
}
export declare function contactsAccountToTerraform(struct?: ContactsAccount | cdktn.IResolvable): any;
export declare function contactsAccountToHclTerraform(struct?: ContactsAccount | cdktn.IResolvable): any;
export declare class ContactsAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContactsAccount | cdktn.IResolvable | undefined;
    set internalValue(value: ContactsAccount | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ContactsAccountList extends cdktn.ComplexList {
    internalValue?: ContactsAccount[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContactsAccountOutputReference;
}
export interface ContactsSecurity {
    /**
    * Email address to send communications to
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts#email Contacts#email}
    */
    readonly email: string;
}
export declare function contactsSecurityToTerraform(struct?: ContactsSecurity | cdktn.IResolvable): any;
export declare function contactsSecurityToHclTerraform(struct?: ContactsSecurity | cdktn.IResolvable): any;
export declare class ContactsSecurityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContactsSecurity | cdktn.IResolvable | undefined;
    set internalValue(value: ContactsSecurity | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ContactsSecurityList extends cdktn.ComplexList {
    internalValue?: ContactsSecurity[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContactsSecurityOutputReference;
}
export interface ContactsSupport {
    /**
    * Email address to send communications to
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts#email Contacts#email}
    */
    readonly email: string;
}
export declare function contactsSupportToTerraform(struct?: ContactsSupport | cdktn.IResolvable): any;
export declare function contactsSupportToHclTerraform(struct?: ContactsSupport | cdktn.IResolvable): any;
export declare class ContactsSupportOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContactsSupport | cdktn.IResolvable | undefined;
    set internalValue(value: ContactsSupport | cdktn.IResolvable | undefined);
    private _email?;
    get email(): string;
    set email(value: string);
    get emailInput(): string | undefined;
}
export declare class ContactsSupportList extends cdktn.ComplexList {
    internalValue?: ContactsSupport[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContactsSupportOutputReference;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts tailscale_contacts}
*/
export declare class Contacts extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_contacts";
    /**
    * Generates CDKTN code for importing a Contacts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Contacts to import
    * @param importFromId The id of the existing Contacts that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Contacts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/contacts tailscale_contacts} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContactsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ContactsConfig);
    get id(): string;
    private _account;
    get account(): ContactsAccountList;
    putAccount(value: ContactsAccount[] | cdktn.IResolvable): void;
    resetAccount(): void;
    get accountInput(): cdktn.IResolvable | ContactsAccount[] | undefined;
    private _security;
    get security(): ContactsSecurityList;
    putSecurity(value: ContactsSecurity[] | cdktn.IResolvable): void;
    resetSecurity(): void;
    get securityInput(): cdktn.IResolvable | ContactsSecurity[] | undefined;
    private _support;
    get support(): ContactsSupportList;
    putSupport(value: ContactsSupport[] | cdktn.IResolvable): void;
    resetSupport(): void;
    get supportInput(): cdktn.IResolvable | ContactsSupport[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
