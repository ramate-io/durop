# `tailscale_dns_search_paths`

Refer to the OpenTofu Registry for docs: [`tailscale_dns_search_paths`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_search_paths).
