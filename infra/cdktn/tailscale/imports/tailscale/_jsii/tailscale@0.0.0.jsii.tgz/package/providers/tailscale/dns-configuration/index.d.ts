import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether or not to enable MagicDNS. Defaults to true.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#magic_dns DnsConfiguration#magic_dns}
    */
    readonly magicDns?: boolean | cdktn.IResolvable;
    /**
    * When enabled, use the configured DNS servers in `nameservers` to resolve names outside the tailnet. When disabled, devices will prefer their local DNS configuration. Defaults to false.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#override_local_dns DnsConfiguration#override_local_dns}
    */
    readonly overrideLocalDns?: boolean | cdktn.IResolvable;
    /**
    * Additional search domains. When MagicDNS is on, the tailnet domain is automatically included as the first search domain.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#search_paths DnsConfiguration#search_paths}
    */
    readonly searchPaths?: string[];
    /**
    * nameservers block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#nameservers DnsConfiguration#nameservers}
    */
    readonly nameservers?: DnsConfigurationNameservers[] | cdktn.IResolvable;
    /**
    * split_dns block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#split_dns DnsConfiguration#split_dns}
    */
    readonly splitDns?: DnsConfigurationSplitDns[] | cdktn.IResolvable;
}
export interface DnsConfigurationNameservers {
    /**
    * The nameserver's IPv4 or IPv6 address
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#address DnsConfiguration#address}
    */
    readonly address: string;
    /**
    * This nameserver will continue to be used when an exit node is selected (requires Tailscale v1.88.1 or later). Defaults to false.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#use_with_exit_node DnsConfiguration#use_with_exit_node}
    */
    readonly useWithExitNode?: boolean | cdktn.IResolvable;
}
export declare function dnsConfigurationNameserversToTerraform(struct?: DnsConfigurationNameservers | cdktn.IResolvable): any;
export declare function dnsConfigurationNameserversToHclTerraform(struct?: DnsConfigurationNameservers | cdktn.IResolvable): any;
export declare class DnsConfigurationNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DnsConfigurationNameservers | cdktn.IResolvable | undefined;
    set internalValue(value: DnsConfigurationNameservers | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _useWithExitNode?;
    get useWithExitNode(): boolean | cdktn.IResolvable;
    set useWithExitNode(value: boolean | cdktn.IResolvable);
    resetUseWithExitNode(): void;
    get useWithExitNodeInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DnsConfigurationNameserversList extends cdktn.ComplexList {
    internalValue?: DnsConfigurationNameservers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DnsConfigurationNameserversOutputReference;
}
export interface DnsConfigurationSplitDnsNameservers {
    /**
    * The nameserver's IPv4 or IPv6 address.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#address DnsConfiguration#address}
    */
    readonly address: string;
    /**
    * This nameserver will continue to be used when an exit node is selected (requires Tailscale v1.88.1 or later). Defaults to false.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#use_with_exit_node DnsConfiguration#use_with_exit_node}
    */
    readonly useWithExitNode?: boolean | cdktn.IResolvable;
}
export declare function dnsConfigurationSplitDnsNameserversToTerraform(struct?: DnsConfigurationSplitDnsNameservers | cdktn.IResolvable): any;
export declare function dnsConfigurationSplitDnsNameserversToHclTerraform(struct?: DnsConfigurationSplitDnsNameservers | cdktn.IResolvable): any;
export declare class DnsConfigurationSplitDnsNameserversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DnsConfigurationSplitDnsNameservers | cdktn.IResolvable | undefined;
    set internalValue(value: DnsConfigurationSplitDnsNameservers | cdktn.IResolvable | undefined);
    private _address?;
    get address(): string;
    set address(value: string);
    get addressInput(): string | undefined;
    private _useWithExitNode?;
    get useWithExitNode(): boolean | cdktn.IResolvable;
    set useWithExitNode(value: boolean | cdktn.IResolvable);
    resetUseWithExitNode(): void;
    get useWithExitNodeInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class DnsConfigurationSplitDnsNameserversList extends cdktn.ComplexList {
    internalValue?: DnsConfigurationSplitDnsNameservers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DnsConfigurationSplitDnsNameserversOutputReference;
}
export interface DnsConfigurationSplitDns {
    /**
    * The nameservers will be used only for this domain.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#domain DnsConfiguration#domain}
    */
    readonly domain: string;
    /**
    * nameservers block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#nameservers DnsConfiguration#nameservers}
    */
    readonly nameservers?: DnsConfigurationSplitDnsNameservers[] | cdktn.IResolvable;
}
export declare function dnsConfigurationSplitDnsToTerraform(struct?: DnsConfigurationSplitDns | cdktn.IResolvable): any;
export declare function dnsConfigurationSplitDnsToHclTerraform(struct?: DnsConfigurationSplitDns | cdktn.IResolvable): any;
export declare class DnsConfigurationSplitDnsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DnsConfigurationSplitDns | cdktn.IResolvable | undefined;
    set internalValue(value: DnsConfigurationSplitDns | cdktn.IResolvable | undefined);
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _nameservers;
    get nameservers(): DnsConfigurationSplitDnsNameserversList;
    putNameservers(value: DnsConfigurationSplitDnsNameservers[] | cdktn.IResolvable): void;
    resetNameservers(): void;
    get nameserversInput(): cdktn.IResolvable | DnsConfigurationSplitDnsNameservers[] | undefined;
}
export declare class DnsConfigurationSplitDnsList extends cdktn.ComplexList {
    internalValue?: DnsConfigurationSplitDns[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DnsConfigurationSplitDnsOutputReference;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration tailscale_dns_configuration}
*/
export declare class DnsConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_dns_configuration";
    /**
    * Generates CDKTN code for importing a DnsConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsConfiguration to import
    * @param importFromId The id of the existing DnsConfiguration that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_configuration tailscale_dns_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsConfigurationConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DnsConfigurationConfig);
    get id(): string;
    private _magicDns?;
    get magicDns(): boolean | cdktn.IResolvable;
    set magicDns(value: boolean | cdktn.IResolvable);
    resetMagicDns(): void;
    get magicDnsInput(): boolean | cdktn.IResolvable | undefined;
    private _overrideLocalDns?;
    get overrideLocalDns(): boolean | cdktn.IResolvable;
    set overrideLocalDns(value: boolean | cdktn.IResolvable);
    resetOverrideLocalDns(): void;
    get overrideLocalDnsInput(): boolean | cdktn.IResolvable | undefined;
    private _searchPaths?;
    get searchPaths(): string[];
    set searchPaths(value: string[]);
    resetSearchPaths(): void;
    get searchPathsInput(): string[] | undefined;
    private _nameservers;
    get nameservers(): DnsConfigurationNameserversList;
    putNameservers(value: DnsConfigurationNameservers[] | cdktn.IResolvable): void;
    resetNameservers(): void;
    get nameserversInput(): cdktn.IResolvable | DnsConfigurationNameservers[] | undefined;
    private _splitDns;
    get splitDns(): DnsConfigurationSplitDnsList;
    putSplitDns(value: DnsConfigurationSplitDns[] | cdktn.IResolvable): void;
    resetSplitDns(): void;
    get splitDnsInput(): cdktn.IResolvable | DnsConfigurationSplitDns[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
