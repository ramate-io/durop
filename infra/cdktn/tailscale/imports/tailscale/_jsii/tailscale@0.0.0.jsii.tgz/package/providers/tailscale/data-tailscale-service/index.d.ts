import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTailscaleServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Service (e.g. `svc:my-service`).
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/service#name DataTailscaleService#name}
    */
    readonly name: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/service tailscale_service}
*/
export declare class DataTailscaleService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tailscale_service";
    /**
    * Generates CDKTN code for importing a DataTailscaleService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTailscaleService to import
    * @param importFromId The id of the existing DataTailscaleService that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTailscaleService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/service tailscale_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTailscaleServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataTailscaleServiceConfig);
    get addrs(): string[];
    get comment(): string;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get ports(): string[];
    get tags(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
