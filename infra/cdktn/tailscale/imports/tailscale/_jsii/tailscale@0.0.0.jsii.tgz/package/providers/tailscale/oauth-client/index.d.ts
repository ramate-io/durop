import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface OauthClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * A description of the OAuth client consisting of alphanumeric characters. Defaults to `""`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/oauth_client#description OauthClient#description}
    */
    readonly description?: string;
    /**
    * Scopes to grant to the client. See https://tailscale.com/kb/1623/ for a list of available scopes.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/oauth_client#scopes OauthClient#scopes}
    */
    readonly scopes: string[];
    /**
    * A list of tags that access tokens generated for the OAuth client will be able to assign to devices. Mandatory if the scopes include "devices:core" or "auth_keys".
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/oauth_client#tags OauthClient#tags}
    */
    readonly tags?: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/oauth_client tailscale_oauth_client}
*/
export declare class OauthClient extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_oauth_client";
    /**
    * Generates CDKTN code for importing a OauthClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the OauthClient to import
    * @param importFromId The id of the existing OauthClient that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/oauth_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the OauthClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/oauth_client tailscale_oauth_client} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options OauthClientConfig
    */
    constructor(scope: Construct, id: string, config: OauthClientConfig);
    get createdAt(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get id(): string;
    get key(): string;
    private _scopes?;
    get scopes(): string[];
    set scopes(value: string[]);
    get scopesInput(): string[] | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    get updatedAt(): string;
    get userId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
