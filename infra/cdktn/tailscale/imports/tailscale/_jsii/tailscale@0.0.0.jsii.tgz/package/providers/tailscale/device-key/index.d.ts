import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DeviceKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The device to update the key properties of
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_key#device_id DeviceKey#device_id}
    */
    readonly deviceId: string;
    /**
    * Determines whether or not the device's key will expire. Defaults to `false`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_key#key_expiry_disabled DeviceKey#key_expiry_disabled}
    */
    readonly keyExpiryDisabled?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_key tailscale_device_key}
*/
export declare class DeviceKey extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_device_key";
    /**
    * Generates CDKTN code for importing a DeviceKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DeviceKey to import
    * @param importFromId The id of the existing DeviceKey that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DeviceKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_key tailscale_device_key} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DeviceKeyConfig
    */
    constructor(scope: Construct, id: string, config: DeviceKeyConfig);
    private _deviceId?;
    get deviceId(): string;
    set deviceId(value: string);
    get deviceIdInput(): string | undefined;
    get id(): string;
    private _keyExpiryDisabled?;
    get keyExpiryDisabled(): boolean | cdktn.IResolvable;
    set keyExpiryDisabled(value: boolean | cdktn.IResolvable);
    resetKeyExpiryDisabled(): void;
    get keyExpiryDisabledInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
