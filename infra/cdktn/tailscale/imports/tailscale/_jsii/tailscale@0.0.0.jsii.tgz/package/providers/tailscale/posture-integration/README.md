# `tailscale_posture_integration`

Refer to the OpenTofu Registry for docs: [`tailscale_posture_integration`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration).
