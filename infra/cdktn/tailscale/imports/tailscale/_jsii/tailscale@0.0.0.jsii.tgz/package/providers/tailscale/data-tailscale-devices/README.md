# `data_tailscale_devices`

Refer to the OpenTofu Registry for docs: [`data_tailscale_devices`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/devices).
