import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsSearchPathsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Devices on your network will use these domain suffixes to resolve DNS names.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_search_paths#search_paths DnsSearchPaths#search_paths}
    */
    readonly searchPaths: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_search_paths tailscale_dns_search_paths}
*/
export declare class DnsSearchPaths extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_dns_search_paths";
    /**
    * Generates CDKTN code for importing a DnsSearchPaths resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsSearchPaths to import
    * @param importFromId The id of the existing DnsSearchPaths that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_search_paths#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsSearchPaths to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_search_paths tailscale_dns_search_paths} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsSearchPathsConfig
    */
    constructor(scope: Construct, id: string, config: DnsSearchPathsConfig);
    get id(): string;
    private _searchPaths?;
    get searchPaths(): string[];
    set searchPaths(value: string[]);
    get searchPathsInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
