import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTailscaleAclConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/acl tailscale_acl}
*/
export declare class DataTailscaleAcl extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tailscale_acl";
    /**
    * Generates CDKTN code for importing a DataTailscaleAcl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTailscaleAcl to import
    * @param importFromId The id of the existing DataTailscaleAcl that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/acl#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTailscaleAcl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/acl tailscale_acl} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTailscaleAclConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTailscaleAclConfig);
    get hujson(): string;
    get id(): string;
    get json(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
