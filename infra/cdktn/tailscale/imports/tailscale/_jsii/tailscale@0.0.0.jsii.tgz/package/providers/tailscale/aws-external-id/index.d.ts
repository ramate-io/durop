import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AwsExternalIdConfig extends cdktn.TerraformMetaArguments {
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/aws_external_id tailscale_aws_external_id}
*/
export declare class AwsExternalId extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_aws_external_id";
    /**
    * Generates CDKTN code for importing a AwsExternalId resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AwsExternalId to import
    * @param importFromId The id of the existing AwsExternalId that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/aws_external_id#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AwsExternalId to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/aws_external_id tailscale_aws_external_id} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AwsExternalIdConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AwsExternalIdConfig);
    get externalId(): string;
    get id(): string;
    get tailscaleAwsAccountId(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
