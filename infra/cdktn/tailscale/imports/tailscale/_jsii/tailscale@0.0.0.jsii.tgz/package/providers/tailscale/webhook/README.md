# `tailscale_webhook`

Refer to the OpenTofu Registry for docs: [`tailscale_webhook`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/webhook).
