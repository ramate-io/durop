# `tailscale_device_tags`

Refer to the OpenTofu Registry for docs: [`tailscale_device_tags`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/device_tags).
