import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsNameserversConfig extends cdktn.TerraformMetaArguments {
    /**
    * Devices on your network will use these nameservers to resolve DNS names. IPv4 or IPv6 addresses are accepted.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_nameservers#nameservers DnsNameservers#nameservers}
    */
    readonly nameservers: string[];
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_nameservers tailscale_dns_nameservers}
*/
export declare class DnsNameservers extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_dns_nameservers";
    /**
    * Generates CDKTN code for importing a DnsNameservers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsNameservers to import
    * @param importFromId The id of the existing DnsNameservers that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_nameservers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsNameservers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_nameservers tailscale_dns_nameservers} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsNameserversConfig
    */
    constructor(scope: Construct, id: string, config: DnsNameserversConfig);
    get id(): string;
    private _nameservers?;
    get nameservers(): string[];
    set nameservers(value: string[]);
    get nameserversInput(): string[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
