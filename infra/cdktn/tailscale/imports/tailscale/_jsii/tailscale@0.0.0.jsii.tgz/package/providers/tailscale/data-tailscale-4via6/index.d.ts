import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTailscale4Via6Config extends cdktn.TerraformMetaArguments {
    /**
    * The IPv4 CIDR to map
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/4via6#cidr DataTailscale4Via6#cidr}
    */
    readonly cidr: string;
    /**
    * Site ID (between 0 and 65535)
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/4via6#site DataTailscale4Via6#site}
    */
    readonly site: number;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/4via6 tailscale_4via6}
*/
export declare class DataTailscale4Via6 extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tailscale_4via6";
    /**
    * Generates CDKTN code for importing a DataTailscale4Via6 resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTailscale4Via6 to import
    * @param importFromId The id of the existing DataTailscale4Via6 that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/4via6#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTailscale4Via6 to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/4via6 tailscale_4via6} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTailscale4Via6Config
    */
    constructor(scope: Construct, id: string, config: DataTailscale4Via6Config);
    private _cidr?;
    get cidr(): string;
    set cidr(value: string);
    get cidrInput(): string | undefined;
    get id(): string;
    get ipv6(): string;
    private _site?;
    get site(): number;
    set site(value: number);
    get siteInput(): number | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
