import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DnsPreferencesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Whether or not to enable magic DNS
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_preferences#magic_dns DnsPreferences#magic_dns}
    */
    readonly magicDns: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_preferences tailscale_dns_preferences}
*/
export declare class DnsPreferences extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_dns_preferences";
    /**
    * Generates CDKTN code for importing a DnsPreferences resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DnsPreferences to import
    * @param importFromId The id of the existing DnsPreferences that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_preferences#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DnsPreferences to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_preferences tailscale_dns_preferences} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DnsPreferencesConfig
    */
    constructor(scope: Construct, id: string, config: DnsPreferencesConfig);
    get id(): string;
    private _magicDns?;
    get magicDns(): boolean | cdktn.IResolvable;
    set magicDns(value: boolean | cdktn.IResolvable);
    get magicDnsInput(): boolean | cdktn.IResolvable | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
