# `tailscale_service`

Refer to the OpenTofu Registry for docs: [`tailscale_service`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/service).
