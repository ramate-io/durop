# `data_tailscale_4via6`

Refer to the OpenTofu Registry for docs: [`data_tailscale_4via6`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/4via6).
