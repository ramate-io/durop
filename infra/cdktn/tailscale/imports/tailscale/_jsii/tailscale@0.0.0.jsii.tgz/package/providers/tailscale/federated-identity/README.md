# `tailscale_federated_identity`

Refer to the OpenTofu Registry for docs: [`tailscale_federated_identity`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/federated_identity).
