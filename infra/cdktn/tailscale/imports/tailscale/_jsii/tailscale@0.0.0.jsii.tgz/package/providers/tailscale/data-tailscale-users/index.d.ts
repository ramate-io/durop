import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataTailscaleUsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter the results to only include users with a specific role. Valid values are `owner`, `member`, `admin`, `it-admin`, `network-admin`, `billing-admin`, and `auditor`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/users#role DataTailscaleUsers#role}
    */
    readonly role?: string;
    /**
    * Filter the results to only include users of a specific type. Valid values are `member` or `shared`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/users#type DataTailscaleUsers#type}
    */
    readonly type?: string;
    /**
    * users block
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/users#users DataTailscaleUsers#users}
    */
    readonly users?: DataTailscaleUsersUsers[] | cdktn.IResolvable;
}
export interface DataTailscaleUsersUsers {
}
export declare function dataTailscaleUsersUsersToTerraform(struct?: DataTailscaleUsersUsers | cdktn.IResolvable): any;
export declare function dataTailscaleUsersUsersToHclTerraform(struct?: DataTailscaleUsersUsers | cdktn.IResolvable): any;
export declare class DataTailscaleUsersUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataTailscaleUsersUsers | cdktn.IResolvable | undefined;
    set internalValue(value: DataTailscaleUsersUsers | cdktn.IResolvable | undefined);
    get created(): string;
    get currentlyConnected(): cdktn.IResolvable;
    get deviceCount(): number;
    get displayName(): string;
    get id(): string;
    get lastSeen(): string;
    get loginName(): string;
    get profilePicUrl(): string;
    get role(): string;
    get status(): string;
    get tailnetId(): string;
    get type(): string;
}
export declare class DataTailscaleUsersUsersList extends cdktn.ComplexList {
    internalValue?: DataTailscaleUsersUsers[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataTailscaleUsersUsersOutputReference;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/users tailscale_users}
*/
export declare class DataTailscaleUsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "tailscale_users";
    /**
    * Generates CDKTN code for importing a DataTailscaleUsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataTailscaleUsers to import
    * @param importFromId The id of the existing DataTailscaleUsers that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataTailscaleUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/users tailscale_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataTailscaleUsersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataTailscaleUsersConfig);
    get id(): string;
    private _role?;
    get role(): string;
    set role(value: string);
    resetRole(): void;
    get roleInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _users;
    get users(): DataTailscaleUsersUsersList;
    putUsers(value: DataTailscaleUsersUsers[] | cdktn.IResolvable): void;
    resetUsers(): void;
    get usersInput(): cdktn.IResolvable | DataTailscaleUsersUsers[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
