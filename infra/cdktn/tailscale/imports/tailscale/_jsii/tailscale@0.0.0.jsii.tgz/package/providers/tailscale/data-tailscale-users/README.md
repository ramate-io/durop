# `data_tailscale_users`

Refer to the OpenTofu Registry for docs: [`data_tailscale_users`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/datasources/users).
