import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PostureIntegrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Unique identifier for your client.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration#client_id PostureIntegration#client_id}
    */
    readonly clientId?: string;
    /**
    * The secret (auth key, token, etc.) used to authenticate with the provider.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration#client_secret PostureIntegration#client_secret}
    */
    readonly clientSecret: string;
    /**
    * Identifies which of the provider's clouds to integrate with.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration#cloud_id PostureIntegration#cloud_id}
    */
    readonly cloudId?: string;
    /**
    * The third-party provider for posture data. Valid values are `falcon`, `fleet`, `huntress`, `intune`, `jamfpro`, `kandji`, `kolide`, and `sentinelone`.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration#posture_provider PostureIntegration#posture_provider}
    */
    readonly postureProvider: string;
    /**
    * The Microsoft Intune directory (tenant) ID. For other providers, this is left blank.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration#tenant_id PostureIntegration#tenant_id}
    */
    readonly tenantId?: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration tailscale_posture_integration}
*/
export declare class PostureIntegration extends cdktn.TerraformResource {
    static readonly tfResourceType = "tailscale_posture_integration";
    /**
    * Generates CDKTN code for importing a PostureIntegration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PostureIntegration to import
    * @param importFromId The id of the existing PostureIntegration that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PostureIntegration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/posture_integration tailscale_posture_integration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PostureIntegrationConfig
    */
    constructor(scope: Construct, id: string, config: PostureIntegrationConfig);
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    get clientSecretInput(): string | undefined;
    private _cloudId?;
    get cloudId(): string;
    set cloudId(value: string);
    resetCloudId(): void;
    get cloudIdInput(): string | undefined;
    get id(): string;
    private _postureProvider?;
    get postureProvider(): string;
    set postureProvider(value: string);
    get postureProviderInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string;
    set tenantId(value: string);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
