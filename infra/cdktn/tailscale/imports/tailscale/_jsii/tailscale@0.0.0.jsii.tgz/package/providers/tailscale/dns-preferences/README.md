# `tailscale_dns_preferences`

Refer to the OpenTofu Registry for docs: [`tailscale_dns_preferences`](https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs/resources/dns_preferences).
