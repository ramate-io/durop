import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface TailscaleProviderConfig {
    /**
    * The API key to use for authenticating requests to the API. Can be set via the TAILSCALE_API_KEY environment variable. If the value starts with 'file:' then it is treated as a path to a file on disk that contains the API key. Conflicts with 'oauth_client_id' and 'oauth_client_secret'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#api_key TailscaleProvider#api_key}
    */
    readonly apiKey?: string;
    /**
    * The OIDC audience to request when discovering an identity token from the runtime (GitHub Actions, AWS, or GCP) for workload identity federation. Can be set via the TAILSCALE_AUDIENCE environment variable. If the value starts with 'file:' then it is treated as a path to a file on disk that contains the audience. Requires 'oauth_client_id'. Conflicts with 'api_key', 'oauth_client_secret', 'identity_token', and 'identity_token_environment_variable_name'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#audience TailscaleProvider#audience}
    */
    readonly audience?: string;
    /**
    * The base URL of the Tailscale API. Defaults to https://api.tailscale.com. Can be set via the TAILSCALE_BASE_URL environment variable.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#base_url TailscaleProvider#base_url}
    */
    readonly baseUrl?: string;
    /**
    * The jwt identity token to exchange for a Tailscale API token when using a federated identity. Can be set via the TAILSCALE_IDENTITY_TOKEN environment variable. If the value starts with 'file:' then it is treated as a path to a file on disk that contains the identity token. Conflicts with 'api_key', 'oauth_client_secret', and 'identity_token_environment_variable_name'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#identity_token TailscaleProvider#identity_token}
    */
    readonly identityToken?: string;
    /**
    * The name of an environment variable to read the identity token from. This is useful when the identity token is provided by an external system (such as Terraform Cloud workload identity) in an environment variable you do not control. If the resolved value of the environment variable starts with 'file:' then it is treated as a path to a file on disk that contains identity token. Conflicts with 'identity_token'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#identity_token_environment_variable_name TailscaleProvider#identity_token_environment_variable_name}
    */
    readonly identityTokenEnvironmentVariableName?: string;
    /**
    * The OAuth application or federated identity's ID when using OAuth client credentials or workload identity federation. Can be set via the TAILSCALE_OAUTH_CLIENT_ID environment variable. If the value starts with 'file:' then it is treated as a path to a file on disk that contains the client ID. Either 'oauth_client_secret' or 'identity_token' must be set alongside 'oauth_client_id'. Conflicts with 'api_key'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#oauth_client_id TailscaleProvider#oauth_client_id}
    */
    readonly oauthClientId?: string;
    /**
    * The OAuth application's secret when using OAuth client credentials. Can be set via the TAILSCALE_OAUTH_CLIENT_SECRET environment variable. If the value starts with 'file:' then it is treated as a path to a file on disk that contains the client secret. Conflicts with 'api_key' and 'identity_token'.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#oauth_client_secret TailscaleProvider#oauth_client_secret}
    */
    readonly oauthClientSecret?: string;
    /**
    * The OAuth 2.0 scopes to request when generating the access token using the supplied OAuth client credentials. See https://tailscale.com/kb/1623/trust-credentials#scopes for available scopes. Only valid when both 'oauth_client_id' and 'oauth_client_secret', or both are set.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#scopes TailscaleProvider#scopes}
    */
    readonly scopes?: string[];
    /**
    * The tailnet ID. Tailnets created before Oct 2025 can still use the legacy ID, but the Tailnet ID is the preferred identifier. Can be set via the TAILSCALE_TAILNET environment variable. Default is the tailnet that owns API credentials passed to the provider.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#tailnet TailscaleProvider#tailnet}
    */
    readonly tailnet?: string;
    /**
    * User-Agent header for API requests.
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#user_agent TailscaleProvider#user_agent}
    */
    readonly userAgent?: string;
    /**
    * Alias name
    *
    * Docs at OpenTofu Registry: {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#alias TailscaleProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs tailscale}
*/
export declare class TailscaleProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "tailscale";
    /**
    * Generates CDKTN code for importing a TailscaleProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the TailscaleProvider to import
    * @param importFromId The id of the existing TailscaleProvider that should be imported. Refer to the {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the TailscaleProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://search.opentofu.org/provider/tailscale/tailscale/v0.29.2/docs tailscale} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options TailscaleProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: TailscaleProviderConfig);
    private _apiKey?;
    get apiKey(): string | undefined;
    set apiKey(value: string | undefined);
    resetApiKey(): void;
    get apiKeyInput(): string | undefined;
    private _audience?;
    get audience(): string | undefined;
    set audience(value: string | undefined);
    resetAudience(): void;
    get audienceInput(): string | undefined;
    private _baseUrl?;
    get baseUrl(): string | undefined;
    set baseUrl(value: string | undefined);
    resetBaseUrl(): void;
    get baseUrlInput(): string | undefined;
    private _identityToken?;
    get identityToken(): string | undefined;
    set identityToken(value: string | undefined);
    resetIdentityToken(): void;
    get identityTokenInput(): string | undefined;
    private _identityTokenEnvironmentVariableName?;
    get identityTokenEnvironmentVariableName(): string | undefined;
    set identityTokenEnvironmentVariableName(value: string | undefined);
    resetIdentityTokenEnvironmentVariableName(): void;
    get identityTokenEnvironmentVariableNameInput(): string | undefined;
    private _oauthClientId?;
    get oauthClientId(): string | undefined;
    set oauthClientId(value: string | undefined);
    resetOauthClientId(): void;
    get oauthClientIdInput(): string | undefined;
    private _oauthClientSecret?;
    get oauthClientSecret(): string | undefined;
    set oauthClientSecret(value: string | undefined);
    resetOauthClientSecret(): void;
    get oauthClientSecretInput(): string | undefined;
    private _scopes?;
    get scopes(): string[] | undefined;
    set scopes(value: string[] | undefined);
    resetScopes(): void;
    get scopesInput(): string[] | undefined;
    private _tailnet?;
    get tailnet(): string | undefined;
    set tailnet(value: string | undefined);
    resetTailnet(): void;
    get tailnetInput(): string | undefined;
    private _userAgent?;
    get userAgent(): string | undefined;
    set userAgent(value: string | undefined);
    resetUserAgent(): void;
    get userAgentInput(): string | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
